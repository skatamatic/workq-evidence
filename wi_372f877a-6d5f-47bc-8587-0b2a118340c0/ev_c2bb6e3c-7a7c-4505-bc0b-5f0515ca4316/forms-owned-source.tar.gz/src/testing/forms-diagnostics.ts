import { TestBed } from '@angular/core/testing';

type Allowance = { message: string; remaining: number };
let allowances: Allowance[] | null = null;

/** Declare the exact single-argument console error expected by this test. */
export function expectFormsConsoleError(message: string, count = 1): void {
  if (!allowances || !Number.isInteger(count) || count < 1) {
    throw new Error('Expected forms errors require an active guarded test and a positive count');
  }
  allowances.push({ message, remaining: count });
}

/** Call first inside describe; register fixture destruction after this call. */
export function useFormsDiagnostics(): void {
  let originalError: typeof console.error;
  let guardedError: typeof console.error;
  let unexpected: string[];

  beforeEach(() => {
    allowances = [];
    unexpected = [];
    originalError = console.error;
    guardedError = (...args: unknown[]) => {
      const allowance = allowances?.find(
        (entry) => entry.remaining > 0 && args.length === 1 && args[0] === entry.message
      );
      if (allowance) {
        allowance.remaining--;
      } else {
        unexpected.push(args.map(String).join(' '));
        originalError(...args);
      }
    };
    console.error = guardedError;
    TestBed.configureTestingModule({ errorOnUnknownElements: true, errorOnUnknownProperties: true });
  });

  afterEach(() => {
    try {
      if (console.error !== guardedError) fail('Forms diagnostic guard was replaced during the test');
      unexpected.forEach((message) => fail(`Unexpected forms console.error: ${message}`));
      allowances?.forEach((entry) => {
        if (entry.remaining)
          fail(`Expected forms console.error was not emitted: ${entry.message} (${entry.remaining})`);
      });
    } finally {
      console.error = originalError;
      allowances = null;
    }
  });
}
