import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { expectFormsConsoleError, useFormsDiagnostics } from './forms-diagnostics';

@Component({ standalone: true, template: '' })
class DiagnosticCanaryComponent {}

describe('forms diagnostic boundary', () => {
  useFormsDiagnostics();

  afterEach(() => TestBed.resetTestingModule());

  it('allows only a declared exact error in its owning test', () => {
    expectFormsConsoleError('Expected forms refusal');
    expect(() => console.error('Expected forms refusal')).not.toThrow();
  });

  it('starts a sibling with no expected errors', () => {
    expect(TestBed.createComponent(DiagnosticCanaryComponent)).toBeTruthy();
  });
});

// Opt-in process canaries: ordinary npm test has no deliberately failing specs.
const canary = (window as unknown as { __karma__: { config: { args: string[] } } }).__karma__.config.args[0];
if (canary) {
  describe(`forms diagnostic negative canary: ${canary}`, () => {
    useFormsDiagnostics();
    afterEach(() => TestBed.resetTestingModule());

    if (canary === 'allowance-leak') {
      it('fails an unused allowance before a sibling starts', () => {
        expectFormsConsoleError('Leaked refusal', 2);
        console.error('Leaked refusal');
      });
    }

    it('must fail the owning test and command', async () => {
      switch (canary) {
        case 'binding': {
          TestBed.overrideTemplate(DiagnosticCanaryComponent, '<div [formsCanaryMissing]="true"></div>');
          TestBed.createComponent(DiagnosticCanaryComponent).detectChanges();
          break;
        }
        case 'console':
          console.error('Unexpected forms canary');
          break;
        case 'missing-allowance':
          expectFormsConsoleError('Never emitted');
          break;
        case 'excess-allowance':
          expectFormsConsoleError('Expected once');
          console.error('Expected once');
          console.error('Expected once');
          break;
        case 'allowance-leak':
          console.error('Leaked refusal');
          break;
        case 'unhandled':
        case 'exception':
          await new Promise<void>((resolve) => {
            // Zone reports rejected promises at microtask drain. The posted
            // message completes on the next task, keeping this spec active.
            const channel = new MessageChannel();
            channel.port1.onmessage = () => {
              channel.port1.close();
              channel.port2.close();
              resolve();
            };
            if (canary === 'unhandled') {
              void Promise.reject(new Error('Unhandled forms canary'));
            } else {
              queueMicrotask(() => {
                throw new Error('Uncaught forms canary');
              });
            }
            channel.port2.postMessage(null);
          });
          break;
        default:
          throw new Error(`Unknown forms diagnostic canary: ${canary}`);
      }
    });
  });
}
