import { Component, input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { useFormsDiagnostics } from '../../../../../testing/forms-diagnostics';
import { SourceTypeEnum } from '@backend/model/enum/source-type.enum';
import { SignatureModel } from '@main/components/work-order/models/signature.model';
import { SingleSignatureComponent } from '@shared/components/signatures-form/single-signature/single-signature.component';
import { EmbeddedRichTextFieldHostComponent } from './embedded-rich-text-field-host.component';
import { RichTextRuntimeFieldComponent } from './rich-text-runtime-field.component';

@Component({
  selector: 'single-signature',
  standalone: true,
  template: '',
})
class SingleSignatureStubComponent {
  signatureModel = input<SignatureModel | null>(null);
  disabled = input(false);
  ruleSourceId = input<string | null>(null);
  compact = input(false);
}

describe('RichTextRuntimeFieldComponent', () => {
  useFormsDiagnostics();
  let fixture: ComponentFixture<RichTextRuntimeFieldComponent>;
  let component: RichTextRuntimeFieldComponent;

  afterEach(() => fixture?.destroy());

  beforeEach(async () => {
    TestBed.overrideComponent(EmbeddedRichTextFieldHostComponent, {
      remove: { imports: [SingleSignatureComponent] },
      add: { imports: [SingleSignatureStubComponent] },
    });
    await TestBed.configureTestingModule({
      imports: [RichTextRuntimeFieldComponent, SingleSignatureStubComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(RichTextRuntimeFieldComponent);
    component = fixture.componentInstance;
  });

  it('renders runtime hosts into app-owned dom for valid placeholders', async () => {
    fixture.componentRef.setInput(
      'value',
      '<p>Before</p><span data-field-id="embedded-1" data-field-type="text" data-display="inline" data-label="Notes"></span>'
    );
    fixture.componentRef.setInput('context', { 'embedded-1': 'Seeded text' });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(component.validationState()).toBeNull();
    expect(fixture.nativeElement.querySelector('[data-embedded-rich-text-runtime-host="true"]')).not.toBeNull();
    expect(fixture.nativeElement.querySelector('.embedded-rich-text-placeholder-builder')).toBeNull();
  });

  it('hydrates mounted hosts from the shared runtime context', async () => {
    fixture.componentRef.setInput(
      'value',
      '<span data-field-id="embedded-1" data-field-type="text" data-display="inline"></span>'
    );
    fixture.componentRef.setInput('context', { 'embedded-1': 'Changed text' });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const runtimeComponent = fixture.debugElement.query(By.css('[data-embedded-rich-text-runtime-host="true"]'));
    expect(runtimeComponent).not.toBeNull();

    const mountedHost = (
      component as unknown as {
        mountedHosts: Map<string, { ref: { instance: { textValue(): string } } }>;
      }
    ).mountedHosts.get('embedded-1');
    expect(mountedHost?.ref.instance.textValue()).toBe('Changed text');
  });

  it('hydrates mounted checkbox hosts from the shared runtime context', async () => {
    fixture.componentRef.setInput(
      'value',
      '<span data-field-id="embedded-flag" data-field-type="checkbox" data-display="inline"></span>'
    );
    fixture.componentRef.setInput('context', { 'embedded-flag': true });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const mountedHost = (
      component as unknown as {
        mountedHosts: Map<string, { ref: { instance: { checkboxValue(): boolean } } }>;
      }
    ).mountedHosts.get('embedded-flag');
    expect(mountedHost?.ref.instance.checkboxValue()).toBeTrue();
  });

  it('unmounts a hidden embedded field and mounts it again when the rule clears', async () => {
    fixture.componentRef.setInput(
      'value',
      '<span data-field-id="embedded-1" data-field-type="text" data-display="inline"></span>'
    );
    fixture.componentRef.setInput('context', { 'embedded-1': 'Retained text' });
    fixture.componentRef.setInput('ruleEffects', { hiddenIds: ['embedded-1'], disabledById: {} });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('[data-embedded-rich-text-runtime-host="true"]')).toBeNull();

    fixture.componentRef.setInput('ruleEffects', { hiddenIds: [], disabledById: {} });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const mountedHost = (
      component as unknown as {
        mountedHosts: Map<string, { ref: { instance: { textValue(): string } } }>;
      }
    ).mountedHosts.get('embedded-1');
    expect(mountedHost?.ref.instance.textValue()).toBe('Retained text');
  });

  it('applies shared disable effects to an already mounted embedded field', async () => {
    fixture.componentRef.setInput(
      'value',
      '<span data-field-id="embedded-1" data-field-type="text" data-display="inline"></span>'
    );
    fixture.componentRef.setInput('context', { 'embedded-1': 'Value' });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const runtimeInternals = component as unknown as {
      mountedHosts: Map<string, { ref: { instance: { disabled(): boolean } } }>;
      renderRuntimeContent: () => void;
    };
    const mountedHosts = runtimeInternals.mountedHosts;
    const initialMountedHost = mountedHosts.get('embedded-1');
    const renderRuntimeContent = spyOn(runtimeInternals, 'renderRuntimeContent').and.callThrough();

    fixture.componentRef.setInput('ruleEffects', {
      hiddenIds: [],
      disabledById: { 'embedded-1': 'forceDisabled' },
    });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const mountedHost = mountedHosts.get('embedded-1');

    expect(renderRuntimeContent).not.toHaveBeenCalled();
    expect(mountedHost?.ref).toBe(initialMountedHost?.ref);
    expect(mountedHost?.ref.instance.disabled()).toBeTrue();
  });

  it('hydrates mounted textarea hosts from the shared runtime context', async () => {
    fixture.componentRef.setInput(
      'value',
      '<div data-field-id="embedded-details" data-field-type="textarea" data-display="block" data-row-count="8"></div>'
    );
    fixture.componentRef.setInput('context', { 'embedded-details': 'Changed details' });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const mountedHost = (
      component as unknown as {
        mountedHosts: Map<
          string,
          { ref: { instance: { textValue(): string; textAreaConfig(): { fsAreaRow?: number } } } }
        >;
      }
    ).mountedHosts.get('embedded-details');
    expect(mountedHost?.ref.instance.textValue()).toBe('Changed details');
    expect(mountedHost?.ref.instance.textAreaConfig().fsAreaRow).toBe(8);
  });

  it('resolves a primitive signature source id from host context for mounted signature hosts', async () => {
    fixture.componentRef.setInput(
      'value',
      '<span data-field-id="embedded-signature" data-field-type="signature" data-display="inline" data-source-type="Work Step" data-form-field-id="operationSignature"></span>'
    );
    fixture.componentRef.setInput('hostContext', { workStepId: 73 });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const mountedHost = (
      component as unknown as {
        mountedHosts: Map<
          string,
          {
            definition: { sourceType?: SourceTypeEnum };
            ref: { instance: { signatureSourceId(): number } };
          }
        >;
      }
    ).mountedHosts.get('embedded-signature');
    expect(mountedHost?.definition.sourceType).toBe(SourceTypeEnum.WORK_STEP);
    expect(mountedHost?.ref.instance.signatureSourceId()).toBe(73);
  });

  it('falls back to -1 when a signature host cannot resolve a source id from host context', async () => {
    fixture.componentRef.setInput(
      'value',
      '<span data-field-id="embedded-signature" data-field-type="signature" data-display="inline" data-source-type="Work Order" data-form-field-id="workOrderSignature"></span>'
    );
    fixture.componentRef.setInput('hostContext', { workCardId: 99 });
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    const mountedHost = (
      component as unknown as {
        mountedHosts: Map<string, { ref: { instance: { signatureSourceId(): number } } }>;
      }
    ).mountedHosts.get('embedded-signature');
    expect(mountedHost?.ref.instance.signatureSourceId()).toBe(-1);
  });
});
