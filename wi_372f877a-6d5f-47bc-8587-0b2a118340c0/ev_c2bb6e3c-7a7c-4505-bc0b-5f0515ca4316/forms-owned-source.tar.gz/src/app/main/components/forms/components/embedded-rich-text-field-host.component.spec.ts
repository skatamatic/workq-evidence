import { Component, input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { useFormsDiagnostics } from '../../../../../testing/forms-diagnostics';
import { SignatureRequiredQualificationEnum } from '@backend/model/enum/signature-required-qualification.enum';
import { SourceTypeEnum } from '@backend/model/enum/source-type.enum';
import { FsTextAreaComponent } from '@flatirons/component-library';
import { SignatureModel } from '@main/components/work-order/models/signature.model';
import { SingleSignatureComponent } from '@shared/components/signatures-form/single-signature/single-signature.component';
import { EmbeddedRichTextFieldHostComponent } from './embedded-rich-text-field-host.component';

@Component({
  selector: 'single-signature',
  standalone: true,
  template: '',
})
class SingleSignatureStubComponent {
  signatureModel = input<SignatureModel | null>(null);
  disabled = input(false);
  ruleSourceId = input<string | null>(null);
  compact = input(false);
}

describe('EmbeddedRichTextFieldHostComponent', () => {
  useFormsDiagnostics();
  let fixture: ComponentFixture<EmbeddedRichTextFieldHostComponent>;
  let component: EmbeddedRichTextFieldHostComponent;

  afterEach(() => fixture?.destroy());

  beforeEach(async () => {
    TestBed.overrideComponent(EmbeddedRichTextFieldHostComponent, {
      remove: { imports: [SingleSignatureComponent] },
      add: { imports: [SingleSignatureStubComponent] },
    });
    await TestBed.configureTestingModule({
      imports: [EmbeddedRichTextFieldHostComponent, SingleSignatureStubComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(EmbeddedRichTextFieldHostComponent);
    component = fixture.componentInstance;
  });

  it('renders a text control and hydrates from the input value', () => {
    fixture.componentRef.setInput('definition', {
      fieldId: 'embedded-notes',
      fieldType: 'text',
      display: 'inline',
      label: 'Embedded Notes',
      placeholder: 'Enter notes',
      required: true,
    });
    fixture.componentRef.setInput('value', 'Seeded text');
    fixture.detectChanges();

    expect(component.isSignatureField()).toBeFalse();
    expect(component.textValue()).toBe('Seeded text');
    expect(component.textFieldConfig().validationType).toBe('required');
    expect(fixture.debugElement.query(By.css('fs-text-field'))).not.toBeNull();
  });

  it('renders a checkbox control and normalizes the input value', () => {
    fixture.componentRef.setInput('definition', {
      fieldId: 'embedded-flag',
      fieldType: 'checkbox',
      display: 'block',
      label: 'Embedded Flag',
      required: true,
    });
    fixture.componentRef.setInput('value', 'truthy');
    fixture.detectChanges();

    expect(component.isSignatureField()).toBeFalse();
    expect(component.checkboxValue()).toBeTrue();
    expect(component.checkboxConfig().label).toBe('Embedded Flag *');
    expect(component.checkboxConfig().fsValidationRequired).toBeTrue();
    expect(fixture.debugElement.query(By.css('fs-checkbox'))).not.toBeNull();
  });

  it('renders a textarea control, binds placeholder via placeHolder, and hydrates from the input value', () => {
    fixture.componentRef.setInput('definition', {
      fieldId: 'embedded-details',
      fieldType: 'textarea',
      display: 'block',
      label: 'Embedded Details',
      placeholder: 'Enter details',
      rowCount: 7,
      required: false,
    });
    fixture.componentRef.setInput('value', 'Seeded details');
    fixture.detectChanges();

    const textArea = fixture.debugElement.query(By.directive(FsTextAreaComponent));
    expect(textArea).not.toBeNull();
    expect(component.textValue()).toBe('Seeded details');
    expect(component.textAreaConfig().validationType).toBe('');
    expect(component.textAreaConfig().fsAreaRow).toBe(7);
    expect(textArea.componentInstance.placeHolder).toBe('Enter details');
  });

  it('updates the local text signal from runtime controls', () => {
    fixture.componentRef.setInput('definition', {
      fieldId: 'embedded-notes',
      fieldType: 'text',
      display: 'inline',
      required: false,
    });
    fixture.detectChanges();

    component.onTextValueChange('Updated text');

    expect(component.textValue()).toBe('Updated text');
  });

  it('builds a standard signature model and renders the single-signature runtime control', () => {
    fixture.componentRef.setInput('definition', {
      fieldId: 'embedded-signature',
      fieldType: 'signature',
      display: 'inline',
      sourceType: SourceTypeEnum.WORK_CARD,
      signatureFormFieldId: 'workCardSignature',
      required: false,
    });
    fixture.componentRef.setInput('signatureSourceId', 42);
    fixture.detectChanges();

    expect(component.isSignatureField()).toBeTrue();
    expect(component.signatureModel()).toEqual({
      formFieldId: 'workCardSignature',
      sourceId: 42,
      sourceType: SourceTypeEnum.WORK_CARD,
      requiredQualification: SignatureRequiredQualificationEnum.TECHNICIAN,
    });
    const signature = fixture.debugElement.query(By.directive(SingleSignatureStubComponent))
      .componentInstance as SingleSignatureStubComponent;
    expect(signature.ruleSourceId()).toBe('embedded-signature');
    expect(signature.compact()).toBeTrue();
    expect(fixture.debugElement.query(By.css('fs-text-field'))).toBeNull();
    expect(fixture.debugElement.query(By.css('fs-checkbox'))).toBeNull();
  });

  it('uses -1 when a signature field has no resolved runtime source id', () => {
    fixture.componentRef.setInput('definition', {
      fieldId: 'embedded-signature',
      fieldType: 'signature',
      display: 'inline',
      sourceType: SourceTypeEnum.WORK_STEP,
      required: false,
    });
    fixture.detectChanges();

    expect(component.signatureModel()).toEqual({
      formFieldId: 'operationSignature',
      sourceId: -1,
      sourceType: SourceTypeEnum.WORK_STEP,
      requiredQualification: SignatureRequiredQualificationEnum.TECHNICIAN,
    });
  });

  it('uses the configured standard signature form type rather than the embedded field id', () => {
    fixture.componentRef.setInput('definition', {
      fieldId: 'embedded-inspector-signature',
      fieldType: 'signature',
      display: 'inline',
      sourceType: SourceTypeEnum.WORK_STEP,
      signatureFormFieldId: 'informationSignature',
      required: false,
    });
    fixture.componentRef.setInput('signatureSourceId', 42);
    fixture.detectChanges();

    expect(component.signatureModel()).toEqual(
      jasmine.objectContaining({
        formFieldId: 'informationSignature',
        sourceId: 42,
        sourceType: SourceTypeEnum.WORK_STEP,
      })
    );
  });
});
