// This file is required by karma.conf.js and loads recursively all the .spec and framework files
import 'zone.js';
import 'zone.js/testing';

import { getTestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';

// First, initialize the Angular testing environment.
getTestBed().initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting());

// ---------------------------------------------------------------------------
// Legacy reporter: prefixes console output with current spec name.
// Forms suites opt into strict assertions via testing/forms-diagnostics.ts.
// ---------------------------------------------------------------------------
(() => {
  let currentSpec = '';

  const origWarn = console.warn.bind(console);
  const origErr = console.error.bind(console);

  jasmine.getEnv().addReporter({
    specStarted: (result) => {
      currentSpec = result.fullName;
      // If you want to see each test start, uncomment:
      // origLog('START:', currentSpec);
    },
    specDone: (result) => {
      if (result.failedExpectations?.length) {
        origErr('FAIL:', result.fullName);
        result.failedExpectations.forEach((e) => origErr('  -', e.message));
      }
      currentSpec = '';
    },
  });

  console.warn = (...args: any[]) => origWarn(currentSpec ? `[${currentSpec}]` : '[no-spec]', ...args);

  console.error = (...args: any[]) => origErr(currentSpec ? `[${currentSpec}]` : '[no-spec]', ...args);
})();
