module.exports = function (config) {
  config.set({
    basePath: '',
    // Updated exclude patterns to correct any potential issues
    exclude: [
      '**/target/**/*.ts', // Ensuring double asterisks for recursive exclusion
      '**/e2e/tests/**/*.spec.ts', // Correcting relative path and ensuring pattern matches
      '**/e2e/pages/*.ts', // Ensuring pattern is matched from the base directory
    ],
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage'),
      require('@angular-devkit/build-angular/plugins/karma'),
    ],
    client: {
      jasmine: {
        // you can add configuration options for Jasmine here
        // the possible options are listed at https://jasmine.github.io/api/edge/Configuration.html
        // for example, you can disable the random execution with `random: false`
        // or set a specific seed with `seed: 4321`
      },
      args: [process.env.FORMS_DIAGNOSTIC_CANARY || ''],
      clearContext: false, // leave Jasmine Spec Runner output visible in browser
    },
    jasmineHtmlReporter: {
      suppressAll: true, // removes the duplicated traces
    },
    coverageReporter: {
      dir: require('path').join(__dirname, './coverage/etc-client', `run-${process.pid}`),
      subdir: '.',
      reporters: [{ type: 'html' }, { type: 'text-summary' }, { type: 'lcov' }],
    },
    reporters: ['progress', 'kjhtml'],
    port: 0,
    colors: true,
    logLevel: process.env.KARMA_LOG_LEVEL === 'debug' ? config.LOG_DEBUG : config.LOG_INFO,
    autoWatch: true,
    browsers: ['ChromeHeadlessNoSandbox'], // Use custom launcher here
    customLaunchers: {
      ChromeHeadlessNoSandbox: {
        base: 'ChromeHeadless',
        flags: [
          '--remote-debugging-port=0',
          '--no-sandbox',
          '--headless',
          '--disable-gpu',
          '--disable-translate',
          '--disable-extensions',
        ],
      },
    },
    singleRun: true,
    restartOnFileChange: true,
  });
};
