# Forms test diagnostics and verification preflight

Forms suites opt into `useFormsDiagnostics()` from `src/testing/forms-diagnostics.ts`
as their first `describe` statement. It enables Angular's unknown-element and
unknown-property errors and fails the owning spec on unexpected `console.error`.
Jasmine and Zone retain their normal uncaught exception and unhandled rejection
handling. Register fixture destruction in `afterEach` after the helper so it runs
while diagnostics are still guarded. Do not replace `console.error` with a spy;
the helper rejects replacement rather than silently losing diagnostic coverage.

Expected refusal cases call `expectFormsConsoleError('exact message', count)` in
the owning test before exercising the refusal. Only that exact single string
argument is allowed, exactly the declared number of times (default one). Missing
and excess emissions fail. Cleanup restores the original console and clears
allowances before sibling tests. Assertions about refusal behavior are still
required; an allowance does not prove the intended business behavior.

The embedded rich-text host and runtime suites use this boundary. Other legacy
tests retain the labeled reporter in `src/test.ts`; this change does not claim
that all legacy console diagnostics have been repaired. Migrate additional
suites explicitly, replacing their expected-error spies with exact allowances.

The full-suite receipt on base `5ec0cfa` with this fix executed 1,644 tests and
returned exit zero. Unrelated diagnostics remain outside these guarded suites:
`WorkOrderSummaryComponent` logs signature-search failures and an undefined
audit-event `map`; `WorkCardStepsComponent` fullscreen tests log signal reads
during the notification phase. These logs explain why console enforcement is
opt-in here. They are not allowlisted or described as repaired by this change.

## Running verification

Set `CHROME_BIN` to the supported executable for the provisioned runtime when
Karma's platform Chrome default is unsuitable. No machine-specific path is
stored in source. Before compiling, run:

```sh
npm run verify:preflight
```

This checks Angular's native compressed LMDB write/read/close mechanism in a
temporary checkout-local cache directory and executes one real Jasmine test in
the selected Karma browser. Cache startup is bounded to 15 seconds; browser
startup/execution is bounded to 30 seconds. Temporary cache and browser profiles
are cleaned up. A failure exits nonzero with runtime/browser guidance.

Use the existing npm/Nx test command:

```sh
NX_DAEMON=false NG_BUILD_MAX_WORKERS=2 npm run test:etc-client -- \
  --watch=false --skip-nx-cache \
  --include=src/app/main/components/forms/components/embedded-rich-text-field-host.component.spec.ts \
  --include=src/app/main/components/forms/components/rich-text-runtime-field.component.spec.ts \
  --include=src/testing/forms-diagnostics.spec.ts
```

For each intentionally failing diagnostic receipt, set
`FORMS_DIAGNOSTIC_CANARY` to `binding`, `console`, `unhandled`, `exception`,
`missing-allowance`, `excess-allowance`, or `allowance-leak` and run the same
command with only `src/testing/forms-diagnostics.spec.ts` included. Each must
return nonzero and name the failed owning spec. Ordinary execution does not
enable these failing tests. Bypass Nx caching for diagnostic and concurrency
receipts so they demonstrate actual browser execution.

Karma binds port zero so the operating system allocates the server port
atomically. Chrome also allocates its debugging port independently and Karma's
launcher creates a separate temporary browser profile per launch. Coverage goes
to `coverage/etc-client/run-<Karma process PID>` within each checkout. Keep
`.angular` and `.nx` as local directories in every checkout, never shared
symlinks. Run lint, unit and build sequentially inside each checkout; independent
checkouts may verify concurrently. This is test infrastructure, not the successor
fixture catalog, product browser harness, or diff selector.
