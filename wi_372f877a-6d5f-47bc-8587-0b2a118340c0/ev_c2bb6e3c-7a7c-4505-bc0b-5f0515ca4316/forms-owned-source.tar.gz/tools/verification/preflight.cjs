const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { Server, config: karmaConfig } = require('karma');
const chrome = require('karma-chrome-launcher');

async function main() {
  const workspace = path.resolve(__dirname, '../..');
  console.log(`Verification runtime: Node ${process.version} ${process.platform}/${process.arch}`);
  const cacheRoot = path.join(workspace, '.angular/cache');
  fs.mkdirSync(cacheRoot, { recursive: true });
  const cache = fs.mkdtempSync(path.join(cacheRoot, 'preflight-'));
  try {
    const result = spawnSync(
      process.execPath,
      [
        '-e',
        `const db = require('lmdb').open({path: process.argv[1], compression: true});
        try {
        db.putSync('preflight', 'ready');
        if (db.get('preflight') !== 'ready') throw new Error('LMDB readback failed');
        } finally { db.close(); }`,
        cache,
      ],
      { cwd: workspace, encoding: 'utf8', timeout: 15000, killSignal: 'SIGKILL' }
    );
    if (result.error || result.status !== 0) {
      throw new Error(
        `Angular LMDB cache preflight failed (${result.signal || result.status}): ${result.error || result.stderr}. Check native-cache execution permissions in this runtime.`
      );
    }
    console.log(`Cache preflight passed: ${cache}`);
  } finally {
    fs.rmSync(cache, { recursive: true, force: true });
  }

  const browser =
    process.env.CHROME_BIN || chrome['launcher:ChromeHeadless'][1].prototype.DEFAULT_CMD[process.platform];
  console.log(`Browser preflight: CHROME_BIN=${browser}; workspace=${workspace}`);
  const config = await karmaConfig.parseConfig(
    undefined,
    {
      configFile: false,
      basePath: __dirname,
      frameworks: ['jasmine'],
      files: ['browser-smoke.spec.js'],
      plugins: [require('karma-jasmine'), chrome],
      browsers: ['PreflightChrome'],
      customLaunchers: {
        PreflightChrome: {
          base: 'ChromeHeadless',
          flags: ['--no-sandbox', '--disable-gpu', '--remote-debugging-port=0'],
        },
      },
      singleRun: true,
      autoWatch: false,
      port: 0,
      captureTimeout: 15000,
      browserNoActivityTimeout: 15000,
      retryLimit: 0,
      reporters: ['dots'],
    },
    { promiseConfig: true, throwErrors: true }
  );
  await new Promise((resolve, reject) => {
    let timedOut = false;
    let startupError;
    const server = new Server(config, (code) => {
      clearTimeout(timer);
      if (startupError) reject(startupError);
      else if (code || timedOut)
        reject(
          new Error(
            `Browser preflight failed (${timedOut ? 'timeout' : code}). Set CHROME_BIN to a supported executable and check browser execution permissions.`
          )
        );
      else resolve();
    });
    const timer = setTimeout(() => {
      timedOut = true;
      server.stop().catch(reject);
    }, 30000);
    server.start().catch((error) => {
      startupError = error;
      clearTimeout(timer);
      server.stop().then(
        () => reject(error),
        () => reject(error)
      );
    });
  });
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
