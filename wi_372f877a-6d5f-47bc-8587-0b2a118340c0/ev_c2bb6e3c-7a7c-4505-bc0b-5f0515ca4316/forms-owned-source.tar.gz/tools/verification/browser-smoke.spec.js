describe('verification preflight browser', function () {
  it('executes in the selected browser', function () {
    expect(document.createElement('div').nodeName).toBe('DIV');
  });
});
