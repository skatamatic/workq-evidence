# Component fixture catalog

The catalog is synthetic test input, separate from product configuration. It starts with Dropdown (FB-013) and embedded rich-text rules (FB-005). It uses the production `Container`, renderer configuration and `FormRuleRegistry` types. The generated product payload retains the existing `structure`/`ruleRegistry` envelope; fixture expectations are never written into that envelope.

## Commands

Use the repository's installed Node/Angular/Nx toolchain:

```bash
npm run forms:fixtures:generate
npm run forms:fixtures:check
NX_DAEMON=false NG_BUILD_MAX_WORKERS=2 npm run forms:fixtures:test -- --output-style=stream
```

Set `CHROME_BIN` to an executable Chromium binary when Chrome is not installed in its normal location. The focused test command uses the existing Nx/Karma executor and repository Karma configuration. Run Nx lint, test and build sequentially. This focused command does not replace the configured full unit gate:

```bash
NX_DAEMON=false NG_BUILD_MAX_WORKERS=2 npm run lint:etc-client -- --output-style=stream
NX_DAEMON=false NG_BUILD_MAX_WORKERS=2 npm run test:etc-client -- --output-style=stream
NX_DAEMON=false NG_BUILD_MAX_WORKERS=2 npm run build:etc-client -- --output-style=stream
```

`generate` recursively discovers sorted `src/testing/form-fixtures/components/**/*.fixture.ts` files, regenerates `registry.generated.ts`, and writes `showcase.generated.json`. `check` refuses missing or stale generated files without updating them. Both prepare the payload with the real `FormBuilderSaveService.buildPayload` in an Angular injection context. The backend service is an unused transport boundary; no HTTP call occurs. The Node generator bundles with the Angular toolchain's esbuild and uses the existing Jest toolchain's jsdom solely for the production embedded HTML parser. It closes that DOM and deletes its process-specific temporary bundle.

To demonstrate production reference validation deliberately failing:

```bash
npm run forms:fixtures:check -- --broken-rule
```

This diagnostic changes a generated request's target to an absent ID and must exit nonzero with `FormBuilderDefinitionValidationError`. It does not modify the source fixtures or generated sample. Do not treat a successful definition reader as reference validation: the reader checks shape/structural identity, while the save service checks the rule graph.

## Add a component

1. Add a `*.fixture.ts` module under `components`, exporting `fixture: ComponentFixture`. No hand-maintained import list or showcase edit is needed.
2. Give the component a stable ID and positive version. Record activity IDs, source paths and current-contract notes; never use customer identities, credentials or archives.
3. Add focused cases using production definition types and production embedded placeholder serialization where applicable. Give every case a stable local ID and every definition/data/rule ID a component-and-case prefix. List required case IDs separately so accidental case removal fails closed.
4. Separate `configuredDefaults` from `currentData`, and declare supported operations, expected hydration, default-stripped definition-save data, rule effects and embedded metadata. Register pending/unsupported capabilities explicitly rather than skipping required cases.
5. Regenerate, check, run the contract tests and normal gates. Commit both generated artifacts. Bump the component version when its contract changes; the SHA-256 catalog hash and source hashes identify the exact definitions and implementation inputs.

The two foundation registrations remain mandatory even if their files disappear. New components are discovered automatically. Catalog validation rejects duplicate component/case IDs, absent required cases, duplicate structural IDs and collisions across cases. Production save validation rejects embedded-ID collisions, duplicate rule IDs and dangling references.

## Successor interface and coverage

Import `fixtures` from `src/testing/form-fixtures/registry.generated.ts` and `generateAllComponentsRequest`/`prepareAllComponents` from `catalog.ts`. The former returns a fresh authoring request; the latter accepts the real save service and returns a production DTO. Alternatively load `showcase.generated.json`: `components` contains the test manifest, while `payload` contains the generated product DTO. The manifest records contract/component versions, semantic catalog SHA-256, source SHA-256 hashes and declared/consumed component-library versions.

Every case is composed into both a root Workcard form and a step subtemplate. IDs intentionally repeat between those independent form scopes, while remaining unique within each scope. Root and step data/registries are cloned independently; the production save path removes the builder-only step ID. The generator does not load the obsolete Allfields JSON.

Dropdown cases cover missing configured-default hydration, explicit `null` and empty-array clears, multiple-selection serialization, required configuration, configured disabled and externally supplied readonly state. Current code/specs preserve explicit clears; older completed FB-013 prose describing clear-to-default behavior is superseded. Definition saving permits empty required current data: runtime submission refusal belongs to the actual control/form handler.

Embedded cases exercise structural sources targeting embedded textarea IDs, embedded sources targeting structural Dropdown IDs, hide/disable/enable effects, configured disabled overridden by enable, external readonly taking precedence, metadata round trips, and populated/cleared retained snapshots. Rules reside in the central registry, never HTML event attributes. Generated placeholder HTML is production authoring preview output; editor bridge cleanup is a pending interaction check.

The browser successor must consume each case's `operations` and `expected.browser`: clear required selections and assert submission refusal; exercise configured disabled and readonly controls; hide a target, change the source so the hide condition no longer matches, and assert the remounted control receives `remountValues` (including explicit clears). It should verify hidden values are omitted from runtime submission while retained for later remount. This ticket's pure contract tests prove save preparation → JSON stringify/parse → production reader, hydration, scoped rule evaluation and metadata. They do not prove mounted controls, TinyMCE cleanup, browser authoring, network persistence or database persistence. No CI job or browser host is added.

Execution receipts, nonzero test counts, timings and any infrastructure failures are attached to the work item. A compilation or generated sample is not a passed Karma run.
