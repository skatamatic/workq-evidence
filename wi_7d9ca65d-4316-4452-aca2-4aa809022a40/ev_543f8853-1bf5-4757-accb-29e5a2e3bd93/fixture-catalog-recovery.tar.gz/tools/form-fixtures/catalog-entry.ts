import '@angular/compiler';
import { createEnvironmentInjector, EnvironmentInjector } from '@angular/core';
import { FormDefinitionService } from '../../src/app/backend/api/form-definitions.service';
import { FormBuilderSaveService } from '../../src/app/main/components/forms/service/form-builder-save.service';
import { generateAllComponentsRequest } from '../../src/testing/form-fixtures/catalog';
import { fixtures } from '../../src/testing/form-fixtures/registry.generated';

/** No transport is called: buildPayload uses the real production preparation path. */
export function generatePayload(brokenRule = false) {
  const injector = createEnvironmentInjector(
    [FormBuilderSaveService, { provide: FormDefinitionService, useValue: {} }],
    null as unknown as EnvironmentInjector
  );
  try {
    const request = generateAllComponentsRequest(fixtures);
    if (brokenRule) request.ruleRegistry.rules[0].targetItemId = 'deliberately-missing-target';
    return injector.get(FormBuilderSaveService).buildPayload(request);
  } finally {
    injector.destroy();
  }
}

export { fixtures } from '../../src/testing/form-fixtures/registry.generated';
export { stableFixtureJson } from '../../src/testing/form-fixtures/catalog';
export { FIXTURE_CONTRACT_VERSION } from '../../src/testing/form-fixtures/fixture-contract';
