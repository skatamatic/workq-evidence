import type { DropdownFieldConfig } from '../../../app/shared/components/dynamic-field/field-renderer.types';
import type { ComponentFixture, FixtureOperation, FixtureValues, FormFixtureCase } from '../fixture-contract';

const options = ['Open', 'Closed'];

function dropdownCase(
  caseId: string,
  config: Partial<DropdownFieldConfig>,
  currentData: FixtureValues,
  hydratedData: FixtureValues,
  persistedData: FixtureValues,
  operations: FixtureOperation[],
  browser: FormFixtureCase['expected']['browser'] = {}
): FormFixtureCase {
  const fieldId = `dropdown-${caseId}-value`;
  return {
    caseId,
    definition: {
      id: `dropdown-${caseId}-root`,
      type: 'container',
      layout: 'column',
      items: [
        {
          id: fieldId,
          type: 'object',
          objectType: 'field',
          fieldType: 'dropdown',
          renderer: { type: 'dropdown', config: { label: 'Fixture selection', data: [...options], ...config } },
        },
      ],
    },
    ruleRegistry: { rules: [] },
    configuredDefaults: config.defaultValue === undefined ? {} : { [fieldId]: config.defaultValue },
    currentData,
    operations,
    expected: { hydratedData, persistedData, browser },
  };
}

export const fixture: ComponentFixture = {
  componentId: 'dropdown',
  version: 1,
  provenance: {
    activities: ['FB-013'],
    sources: [
      'docs/design/form-builder/completed/fb-013-standardize-dropdown-field-configuration.md',
      'src/app/main/components/forms/utils/builder-default-value.util.ts',
      'src/app/main/components/forms/utils/dropdown-field-config.util.ts',
      'src/app/shared/components/form-renderer/form-renderer.component.spec.ts',
    ],
    contractNotes: [
      'Current implementation preserves explicit null and empty-array runtime clears; this supersedes the older FB-013 clear-to-default prose.',
      'Required refusal is a runtime control expectation, not definition-save validation.',
      'Readonly is supplied by the renderer context; Dropdown persists configured disabled, not a separate readonly property.',
    ],
  },
  requiredCaseIds: [
    'default',
    'explicit-null-clear',
    'multiple-empty-clear',
    'selection',
    'required',
    'configured-disabled',
    'readonly',
  ],
  cases: [
    dropdownCase('default', { defaultValue: 'Open' }, {}, { 'dropdown-default-value': 'Open' }, {}, ['hydrate']),
    dropdownCase(
      'explicit-null-clear',
      { defaultValue: 'Open' },
      { 'dropdown-explicit-null-clear-value': null },
      { 'dropdown-explicit-null-clear-value': null },
      { 'dropdown-explicit-null-clear-value': null },
      ['clear', 'hydrate', 'remount'],
      { remountValues: { 'dropdown-explicit-null-clear-value': null } }
    ),
    dropdownCase(
      'multiple-empty-clear',
      { multiple: true, defaultValue: ['Open'] },
      { 'dropdown-multiple-empty-clear-value': [] },
      { 'dropdown-multiple-empty-clear-value': [] },
      { 'dropdown-multiple-empty-clear-value': [] },
      ['clear', 'hydrate', 'remount'],
      { remountValues: { 'dropdown-multiple-empty-clear-value': [] } }
    ),
    dropdownCase(
      'selection',
      { multiple: true, defaultValue: ['Open'] },
      { 'dropdown-selection-value': ['Closed', 'Open'] },
      { 'dropdown-selection-value': ['Closed', 'Open'] },
      { 'dropdown-selection-value': ['Closed', 'Open'] },
      ['select', 'submit']
    ),
    dropdownCase(
      'required',
      { validationType: 'required', fsErrorMsg: 'Choose a fixture option.' },
      { 'dropdown-required-value': null },
      { 'dropdown-required-value': null },
      { 'dropdown-required-value': null },
      ['clear', 'submit'],
      { requiredRefusal: ['dropdown-required-value'] }
    ),
    dropdownCase(
      'configured-disabled',
      { disabled: true, defaultValue: 'Open' },
      { 'dropdown-configured-disabled-value': 'Closed' },
      { 'dropdown-configured-disabled-value': 'Closed' },
      { 'dropdown-configured-disabled-value': 'Closed' },
      ['disable', 'submit'],
      { disabledIds: ['dropdown-configured-disabled-value'] }
    ),
    dropdownCase(
      'readonly',
      { defaultValue: 'Open' },
      { 'dropdown-readonly-value': 'Closed' },
      { 'dropdown-readonly-value': 'Closed' },
      { 'dropdown-readonly-value': 'Closed' },
      ['readonly', 'submit'],
      { readonlyIds: ['dropdown-readonly-value'] }
    ),
  ],
  capabilities: [
    {
      id: 'configured-default-and-explicit-clear',
      status: 'supported',
      reason: 'Production default hydration distinguishes missing and cleared runtime values.',
    },
    {
      id: 'single-and-multiple-selection',
      status: 'supported',
      reason: 'Production Dropdown persists string and string-array selections.',
    },
    {
      id: 'required-disabled-readonly',
      status: 'supported',
      reason: 'Control validation and renderer disabled context are browser successor interaction cases.',
    },
    {
      id: 'dynamic-value-sets',
      status: 'pending',
      reason: 'FB-037 owns server-managed options; these fixtures use static production string options.',
    },
    {
      id: 'object-options-and-async-loaders',
      status: 'unsupported',
      reason: 'Current Dropdown contract supports static string options only.',
    },
  ],
};
