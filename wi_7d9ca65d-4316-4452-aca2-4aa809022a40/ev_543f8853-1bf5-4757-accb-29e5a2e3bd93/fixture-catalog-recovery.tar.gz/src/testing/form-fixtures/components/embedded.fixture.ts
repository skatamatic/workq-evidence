import type { ComponentFixture, FormFixtureCase, FixtureOperation } from '../fixture-contract';
import type { EmbeddedRichTextFieldDefinition } from '../../../app/main/components/forms/models/embedded-rich-text-field.model';
import type { SupportedFormRuleAction } from '../../../app/main/components/forms/models/form-rule.model';
import { renderEmbeddedFieldPlaceholderHtml } from '../../../app/main/components/forms/utils/embedded-rich-text-placeholder.util';
import { makeRendererConfig } from '../../../app/main/components/forms/utils/renderer-config.util';

function ruleCase(
  caseId: string,
  action: SupportedFormRuleAction,
  embeddedSource = false,
  remountValue?: string
): FormFixtureCase {
  const prefix = `embedded-${caseId}`;
  const sourceId = `${prefix}-source`;
  const targetId = `${prefix}-target`;
  const documentId = `${prefix}-document`;
  const embedded: EmbeddedRichTextFieldDefinition = embeddedSource
    ? {
        fieldId: sourceId,
        fieldType: 'text',
        display: 'inline',
        label: 'Rule source',
        placeholder: 'Enter a rule trigger',
        required: false,
      }
    : {
        fieldId: targetId,
        fieldType: 'textarea',
        display: 'block',
        label: 'Embedded notes',
        placeholder: 'Enter notes',
        rowCount: 4,
        required: true,
        hideLabel: true,
      };
  const currentData = {
    [documentId]: renderEmbeddedFieldPlaceholderHtml(embedded),
    [sourceId]: action,
    [targetId]: remountValue ?? 'Retained notes',
  };
  const operations: FixtureOperation[] = ['hydrate', action];
  if (remountValue !== undefined) {
    operations.push('remount');
  }
  return {
    caseId,
    definition: {
      id: `${prefix}-root`,
      type: 'container',
      layout: 'column',
      items: [
        {
          id: embeddedSource ? targetId : sourceId,
          type: 'object',
          objectType: 'field',
          fieldType: 'dropdown',
          renderer: makeRendererConfig('dropdown', {
            label: embeddedSource ? 'Structural target' : 'Rule source',
            data: ['hide', 'disable', 'enable', 'Retained notes'],
            disabled: action === 'enable' && embeddedSource,
          }),
        },
        {
          id: documentId,
          type: 'object',
          objectType: 'richText',
          toolboxLabelKey: 'richText',
          viewRenderer: 'embeddedRuntime',
        },
      ],
    },
    ruleRegistry: {
      rules: [
        {
          ruleId: `${prefix}-rule`,
          sourceItemId: sourceId,
          targetItemId: targetId,
          sourceKey: 'field.value',
          condition: { operator: 'equals', value: action },
          action,
        },
      ],
    },
    configuredDefaults: {},
    currentData,
    operations,
    expected: {
      hydratedData: structuredClone(currentData),
      persistedData: structuredClone(currentData),
      effects: {
        hiddenIds: action === 'hide' ? [targetId] : [],
        disabledById: action === 'hide' ? {} : { [targetId]: action === 'disable' ? 'forceDisabled' : 'forceEnabled' },
      },
      embeddedDefinitions: [embedded],
      browser: {
        ...(action === 'disable' ? { disabledIds: [targetId] } : {}),
        ...(remountValue !== undefined ? { remountValues: { [targetId]: remountValue } } : {}),
      },
    },
  };
}

export const fixture: ComponentFixture = {
  componentId: 'embedded',
  version: 1,
  provenance: {
    activities: ['FB-005'],
    sources: [
      'docs/design/form-builder/completed/fb-005-embedded-rich-text-rules.md',
      'src/app/main/components/forms/utils/embedded-rich-text-placeholder.util.ts',
      'src/app/shared/components/form-renderer/form-rule-engine.ts',
      'src/app/shared/components/form-renderer/form-renderer.component.spec.ts',
    ],
    contractNotes: [
      'Rules use the production form-scoped registry and explicit source/target IDs, never HTML events.',
      'The hide case targets an embedded field; disable and enable use an embedded source and structural target.',
      'Placeholder HTML is production authoring preview output. TinyMCE bridge cleanup and actual remount interaction require the successor browser host.',
      'Remount expectations retain populated and explicitly cleared values; pure snapshots do not prove DOM mounting.',
    ],
  },
  requiredCaseIds: ['hide', 'disable', 'enable', 'remount-populated', 'remount-clear'],
  cases: [
    ruleCase('hide', 'hide'),
    ruleCase('disable', 'disable', true),
    ruleCase('enable', 'enable', true),
    ruleCase('remount-populated', 'hide', false, 'Retained notes'),
    ruleCase('remount-clear', 'hide', false, ''),
  ],
  capabilities: [
    {
      id: 'scoped-rule-effects',
      status: 'supported',
      reason: 'Production registry validation and rule evaluation share form-scoped IDs.',
    },
    {
      id: 'embedded-metadata',
      status: 'supported',
      reason: 'The strict production placeholder reader preserves declared field metadata.',
    },
    {
      id: 'browser-remount',
      status: 'pending',
      reason: 'Value expectations are registered for the successor isolated browser host.',
    },
    {
      id: 'tinymce-save-cleanup',
      status: 'pending',
      reason: 'Preview artifact removal requires the production editor bridge interaction.',
    },
    {
      id: 'legacy-javascript-events',
      status: 'unsupported',
      reason: 'Legacy HTML events are ignored; current rules are central registry entries.',
    },
    {
      id: 'required-optional-rule-actions',
      status: 'unsupported',
      reason: 'The production rule action contract supports hide, disable, and enable only.',
    },
  ],
};
