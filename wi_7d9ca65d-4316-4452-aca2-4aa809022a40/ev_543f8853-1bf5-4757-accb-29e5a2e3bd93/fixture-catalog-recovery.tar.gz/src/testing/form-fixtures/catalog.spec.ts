import { TestBed } from '@angular/core/testing';
import { FormDefinitionService } from '../../app/backend/api/form-definitions.service';
import type { IFormDefinitionDto } from '../../app/backend/model/interface/form-definition-dto.interface';
import {
  FormBuilderSaveService,
  FormBuilderDefinitionValidationError,
} from '../../app/main/components/forms/service/form-builder-save.service';
import { readPersistedFormDefinition } from '../../app/main/components/forms/utils/form-definition-data.util';
import {
  applyConfiguredDefaults,
  configuredDefaultValue,
} from '../../app/main/components/forms/utils/builder-default-value.util';
import { walkBuilderNodes } from '../../app/main/components/forms/utils/container-traversal.util';
import { buildFormRuleCatalog } from '../../app/main/components/forms/utils/form-rule-catalog.util';
import { readEmbeddedRichTextDocument } from '../../app/main/components/forms/utils/embedded-rich-text-document-reader.util';
import { evaluateRules, applyRules } from '../../app/shared/components/form-renderer/form-rule-engine';
import { readFieldRendererConfig } from '../../app/main/components/forms/utils/renderer-config.util';
import {
  generateAllComponentsRequest,
  prepareAllComponents,
  stableFixtureJson,
  validateFixtureCatalog,
} from './catalog';
import { fixtures } from './registry.generated';
import type { FixtureValues, FormFixtureCase } from './fixture-contract';

describe('form fixture catalog contract', () => {
  let service: FormBuilderSaveService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FormBuilderSaveService, { provide: FormDefinitionService, useValue: {} }],
    });
    service = TestBed.inject(FormBuilderSaveService);
  });

  function roundTrip(entry: FormFixtureCase): IFormDefinitionDto {
    const request = generateAllComponentsRequest(fixtures);
    request.container = structuredClone(entry.definition);
    request.formData = structuredClone(entry.currentData);
    request.ruleRegistry = structuredClone(entry.ruleRegistry);
    request.subtemplates[0].formDefinition = structuredClone(entry.definition);
    request.subtemplates[0].formData = structuredClone(entry.currentData);
    request.subtemplates[0].ruleRegistry = structuredClone(entry.ruleRegistry);
    return JSON.parse(JSON.stringify(service.buildPayload(request)));
  }

  for (const fixture of fixtures) {
    for (const entry of fixture.cases) {
      it(`${fixture.componentId}/${entry.caseId}: real save/stringify/reader in both scopes`, () => {
        const before = stableFixtureJson(entry);
        const payload = roundTrip(entry);
        const root = readPersistedFormDefinition(payload.formDefinition)!;
        const step = readPersistedFormDefinition(payload.subtemplates![0].formDefinition)!;
        expect(root).not.toBeNull();
        expect(step).toEqual(root);
        expect(root.structure).toEqual(entry.definition);
        expect(root.ruleRegistry).toEqual(entry.ruleRegistry);
        expect(payload.formData).toEqual(entry.expected.persistedData);
        expect(payload.subtemplates![0].formData).toEqual(entry.expected.persistedData);
        expect(payload.subtemplates![0].id).toBeUndefined();
        expect(payload.subtemplates![0].metadata).toEqual({ fixtureScope: 'subtemplate' });
        expect(stableFixtureJson(entry)).toBe(before);
      });

      it(`${fixture.componentId}/${entry.caseId}: configured defaults and current values stay distinct`, () => {
        const defaults: FixtureValues = {};
        walkBuilderNodes(entry.definition, (node) => {
          const value = configuredDefaultValue(node);
          if (value !== undefined) defaults[node.id] = value;
        });
        expect(defaults).toEqual(entry.configuredDefaults);
        expect(applyConfiguredDefaults(entry.definition, entry.currentData)).toEqual(entry.expected.hydratedData);
        const payload = roundTrip(entry);
        expect(
          applyConfiguredDefaults(readPersistedFormDefinition(payload.formDefinition)!.structure, payload.formData)
        ).toEqual(entry.expected.hydratedData);
        // Remount data is a retained snapshot contract; actual control mounting is a browser requirement.
        for (const [id, value] of Object.entries(entry.expected.browser.remountValues ?? {})) {
          expect(payload.formData![id]).toEqual(value);
        }
      });

      it(`${fixture.componentId}/${entry.caseId}: production rule effects and observable metadata`, () => {
        const payload = roundTrip(entry);
        const root = readPersistedFormDefinition(payload.formDefinition)!;
        const catalog = buildFormRuleCatalog(root.structure, payload.formData ?? {});
        expect(catalog.errors).toEqual([]);
        const effects = evaluateRules(catalog, root.ruleRegistry, entry.expected.hydratedData);
        expect(effects).toEqual(entry.expected.effects ?? { hiddenIds: [], disabledById: {} });
        const embedded = root.structure.items.filter(
          (item) => item.type === 'object' && item.objectType === 'richText'
        );
        const metadata = embedded.flatMap((item) => {
          const result = readEmbeddedRichTextDocument(payload.formData![item.id] as string);
          expect(result.errors).toEqual([]);
          return result.definitions;
        });
        expect(metadata).toEqual(entry.expected.embeddedDefinitions ?? []);
        const rendered = applyRules(root.structure, effects)!;
        for (const id of entry.expected.browser.disabledIds ?? []) {
          expect(catalog.nodes.map((node) => node.id)).toContain(id);
          let checked = false;
          walkBuilderNodes(rendered, (node) => {
            if (node.id === id && node.type === 'object' && node.objectType === 'field') {
              checked = true;
              expect(readFieldRendererConfig<{ disabled?: boolean }>(node)?.disabled).toBeTrue();
            }
          });
          expect(checked).toBeTrue();
        }
        for (const id of entry.expected.browser.requiredRefusal ?? []) {
          let checked = false;
          walkBuilderNodes(root.structure, (node) => {
            if (node.id === id && node.type === 'object' && node.objectType === 'field') {
              checked = true;
              expect(readFieldRendererConfig<{ validationType?: string }>(node)?.validationType).toBe('required');
            }
          });
          expect(checked).toBeTrue();
        }
        const readonly = applyRules(root.structure, effects, true)!;
        for (const id of entry.expected.browser.readonlyIds ?? []) {
          let checked = false;
          walkBuilderNodes(readonly, (node) => {
            if (node.id === id && node.type === 'object' && node.objectType === 'field') {
              checked = true;
              expect(readFieldRendererConfig<{ disabled?: boolean }>(node)?.disabled).toBeTrue();
            }
          });
          expect(checked).toBeTrue();
        }
      });
    }
  }

  it('generates byte-stable fresh objects without mutating any source fixture', () => {
    const before = stableFixtureJson(fixtures);
    const first = prepareAllComponents(fixtures, service);
    const second = prepareAllComponents([...fixtures].reverse(), service);
    expect(stableFixtureJson(first)).toBe(stableFixtureJson(second));
    expect(first.formDefinition).not.toBe(second.formDefinition);
    expect(stableFixtureJson(fixtures)).toBe(before);
  });

  it('strips builder duplicates of defaults in root and subtemplate while preserving missing-value hydration', () => {
    const request = generateAllComponentsRequest(fixtures);
    request.formData['dropdown-default-value'] = 'Open';
    request.subtemplates[0].formData!['dropdown-default-value'] = 'Open';
    const payload = service.buildPayload(request);
    expect(payload.formData!['dropdown-default-value']).toBeUndefined();
    expect(payload.subtemplates![0].formData!['dropdown-default-value']).toBeUndefined();
    expect(applyConfiguredDefaults(request.container!, {})['dropdown-default-value']).toBe('Open');
  });
  it('hide release leaves the retained populated and cleared snapshots available for remount', () => {
    const entries = fixtures
      .find((fixture) => fixture.componentId === 'embedded')!
      .cases.filter((entry) => entry.operations.includes('remount'));
    expect(entries.length).toBe(2);
    for (const entry of entries) {
      const values = structuredClone(entry.currentData);
      values[entry.ruleRegistry.rules[0].sourceItemId] = 'enable';
      const catalog = buildFormRuleCatalog(entry.definition, values);
      expect(evaluateRules(catalog, entry.ruleRegistry, values).hiddenIds).toEqual([]);
      for (const [id, value] of Object.entries(entry.expected.browser.remountValues!))
        expect(values[id]).toEqual(value);
    }
  });

  it('rejects a missing required component registration', () => {
    expect(() => validateFixtureCatalog(fixtures.filter((fixture) => fixture.componentId !== 'dropdown'))).toThrowError(
      /Missing required registration/
    );
  });
  it('rejects a missing required case rather than silently reducing coverage', () => {
    const broken = structuredClone(fixtures);
    broken[0].cases.pop();
    expect(() => validateFixtureCatalog(broken)).toThrowError(/Missing required case/);
  });
  it('rejects duplicate component and case IDs', () => {
    expect(() => validateFixtureCatalog([...fixtures, fixtures[0]])).toThrowError(/Duplicate or empty component/);
    const broken = structuredClone(fixtures);
    broken[0].cases.push(broken[0].cases[0]);
    expect(() => validateFixtureCatalog(broken)).toThrowError(/Duplicate or empty case/);
  });
  it('rejects duplicate structural IDs before preparation', () => {
    const broken = structuredClone(fixtures);
    broken[0].cases[0].definition.items.push(structuredClone(broken[0].cases[0].definition.items[0]));
    expect(() => generateAllComponentsRequest(broken)).toThrowError(/duplicate IDs/);
  });
  it('rejects duplicate IDs across otherwise valid cases in the composed form', () => {
    const broken = structuredClone(fixtures);
    broken[0].cases[1].definition.id = broken[0].cases[0].definition.id;
    expect(() => generateAllComponentsRequest(broken)).toThrowError(/duplicate IDs/);
  });
  it('deliberately broken-rule fixture fails real save validation although the reader accepts its shape', () => {
    const broken = structuredClone(fixtures);
    const entry = broken.find((fixture) => fixture.componentId === 'embedded')!.cases[0];
    entry.ruleRegistry.rules[0].targetItemId = 'missing-target';
    expect(
      readPersistedFormDefinition({ structure: entry.definition, ruleRegistry: entry.ruleRegistry })
    ).not.toBeNull();
    expect(() => prepareAllComponents(broken, service)).toThrowError(FormBuilderDefinitionValidationError);
  });
  it('rejects dangling sources, duplicate rule IDs and embedded IDs', () => {
    const request = generateAllComponentsRequest(fixtures);
    request.ruleRegistry.rules[0].sourceItemId = 'missing-source';
    expect(() => service.buildPayload(request)).toThrowError(FormBuilderDefinitionValidationError);
    const duplicateRule = generateAllComponentsRequest(fixtures);
    duplicateRule.ruleRegistry.rules.push(structuredClone(duplicateRule.ruleRegistry.rules[0]));
    expect(() => service.buildPayload(duplicateRule)).toThrowError(FormBuilderDefinitionValidationError);
    const duplicateEmbedded = generateAllComponentsRequest(fixtures);
    const documentId = fixtures.find((fixture) => fixture.componentId === 'embedded')!.cases[0].definition.items[1].id;
    duplicateEmbedded.formData[documentId] =
      String(duplicateEmbedded.formData[documentId]) + String(duplicateEmbedded.formData[documentId]);
    expect(() => service.buildPayload(duplicateEmbedded)).toThrowError(FormBuilderDefinitionValidationError);
  });
  it('refuses a step rule referencing a field that only exists in the root scope', () => {
    const request = generateAllComponentsRequest(fixtures);
    request.subtemplates[0].formDefinition = { id: 'empty-step', type: 'container', layout: 'column', items: [] };
    expect(() => service.buildPayload(request)).toThrowError(FormBuilderDefinitionValidationError);
  });
  it('enable overrides configured disabled but cannot override readonly', () => {
    const entry = fixtures
      .find((fixture) => fixture.componentId === 'embedded')!
      .cases.find((entry) => entry.caseId === 'enable')!;
    const catalog = buildFormRuleCatalog(entry.definition, entry.currentData);
    const effects = evaluateRules(catalog, entry.ruleRegistry, entry.currentData);
    const target = entry.ruleRegistry.rules[0].targetItemId;
    for (const externalDisabled of [false, true]) {
      const rendered = applyRules(entry.definition, effects, externalDisabled)!;
      const field = rendered.items.find((item) => item.id === target)!;
      expect(field.type === 'object' && field.objectType === 'field').toBeTrue();
      if (field.type === 'object' && field.objectType === 'field') {
        expect(readFieldRendererConfig<{ disabled?: boolean }>(field)?.disabled).toBe(externalDisabled);
      }
    }
  });
});
