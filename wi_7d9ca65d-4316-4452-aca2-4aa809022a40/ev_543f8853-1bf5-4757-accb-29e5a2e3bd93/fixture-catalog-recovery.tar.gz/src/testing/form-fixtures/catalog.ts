import type {
  FormBuilderPayloadRequest,
  FormBuilderSaveService,
} from '../../app/main/components/forms/service/form-builder-save.service';
import { readPersistedFormDefinition } from '../../app/main/components/forms/utils/form-definition-data.util';
import type { ComponentFixture, FixtureValues } from './fixture-contract';

/** Foundation registrations are mandatory even if their module disappears. */
export const REQUIRED_COMPONENT_IDS = ['dropdown', 'embedded'] as const;

export function validateFixtureCatalog(fixtures: readonly ComponentFixture[]): void {
  const components = new Set<string>();
  for (const fixture of fixtures) {
    if (!fixture.componentId || components.has(fixture.componentId)) {
      throw new Error(`Duplicate or empty component ID: ${fixture.componentId}`);
    }
    components.add(fixture.componentId);
    if (
      !Number.isInteger(fixture.version) ||
      fixture.version < 1 ||
      !fixture.cases.length ||
      !fixture.requiredCaseIds.length
    ) {
      throw new Error(`Missing version or required cases: ${fixture.componentId}`);
    }
    const cases = new Set<string>();
    for (const entry of fixture.cases) {
      if (!entry.caseId || cases.has(entry.caseId)) throw new Error(`Duplicate or empty case ID: ${entry.caseId}`);
      cases.add(entry.caseId);
      if (!entry.operations.length) throw new Error(`Missing operations: ${entry.caseId}`);
      if (!readPersistedFormDefinition({ structure: entry.definition, ruleRegistry: entry.ruleRegistry })) {
        throw new Error(`Invalid structure or duplicate IDs: ${fixture.componentId}/${entry.caseId}`);
      }
    }
    for (const required of fixture.requiredCaseIds) {
      if (!cases.has(required)) throw new Error(`Missing required case: ${fixture.componentId}/${required}`);
    }
  }
  for (const required of REQUIRED_COMPONENT_IDS) {
    if (!components.has(required)) throw new Error(`Missing required registration: ${required}`);
  }
}

/** Every invocation builds fresh product objects; no generated giant form is edited. */
export function generateAllComponentsRequest(fixtures: readonly ComponentFixture[]): FormBuilderPayloadRequest {
  validateFixtureCatalog(fixtures);
  const entries = [...fixtures]
    .sort((a, b) => a.componentId.localeCompare(b.componentId))
    .flatMap((fixture) => [...fixture.cases].sort((a, b) => a.caseId.localeCompare(b.caseId)));
  const container = {
    id: 'fixture-showcase-root',
    type: 'container' as const,
    layout: 'column' as const,
    items: entries.map((entry) => structuredClone(entry.definition)),
  };
  const formData: FixtureValues = {};
  for (const entry of entries) {
    for (const [id, value] of Object.entries(entry.currentData)) {
      if (Object.prototype.hasOwnProperty.call(formData, id)) throw new Error(`Duplicate current-data ID: ${id}`);
      formData[id] = structuredClone(value);
    }
  }
  const ruleRegistry = { rules: entries.flatMap((entry) => structuredClone(entry.ruleRegistry.rules)) };
  if (!readPersistedFormDefinition({ structure: container, ruleRegistry })) {
    throw new Error('Composed showcase contains invalid or duplicate IDs');
  }
  return {
    formType: 'Workcard',
    libraryId: 0,
    container,
    formData,
    ruleRegistry,
    dialog: {
      name: 'All registered component fixtures',
      description: 'Synthetic contract showcase',
      revisionComment: 'fixture-catalog-v1',
      usageType: 'Operation',
    },
    subtemplates: [
      {
        id: 'fixture-builder-step',
        seqPath: '1',
        ordinal: 0,
        title: 'Scoped component fixtures',
        stepType: 'Operation',
        formDefinition: { ...structuredClone(container), id: 'fixture-showcase-step' },
        formData: structuredClone(formData),
        ruleRegistry: structuredClone(ruleRegistry),
        metadata: { fixtureScope: 'subtemplate' },
      },
    ],
  };
}

/** The injected production service validates references and strips default duplicates. */
export function prepareAllComponents(
  fixtures: readonly ComponentFixture[],
  saveService: Pick<FormBuilderSaveService, 'buildPayload'>
) {
  return saveService.buildPayload(generateAllComponentsRequest(fixtures));
}

export function stableFixtureJson(value: unknown): string {
  const serialized = JSON.stringify(
    value,
    (_key, entry) => {
      if (entry && typeof entry === 'object' && !Array.isArray(entry)) {
        return Object.fromEntries(
          Object.keys(entry)
            .sort()
            .map((key) => [key, entry[key]])
        );
      }
      return entry;
    },
    2
  );
  return `${serialized}\n`;
}
