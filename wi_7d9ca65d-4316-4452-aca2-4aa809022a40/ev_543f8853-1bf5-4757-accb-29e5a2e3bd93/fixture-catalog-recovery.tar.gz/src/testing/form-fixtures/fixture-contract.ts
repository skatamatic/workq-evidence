import type { Container } from '../../app/main/components/forms/models/builder-item.model';
import type { FormRuleRegistry, RuleEffects } from '../../app/main/components/forms/models/form-rule.model';
import type { EmbeddedRichTextFieldDefinition } from '../../app/main/components/forms/models/embedded-rich-text-field.model';
import type { GenericFormValue } from '../../app/shared/components/dynamic-forms/dynamic-forms.component';

export type FixtureValues = Record<string, GenericFormValue>;
export type FixtureOperation =
  'hydrate' | 'select' | 'clear' | 'submit' | 'readonly' | 'hide' | 'disable' | 'enable' | 'remount';

/** Test metadata wraps, rather than replaces, the production definition schema. */
export interface FormFixtureCase {
  caseId: string;
  definition: Container;
  ruleRegistry: FormRuleRegistry;
  configuredDefaults: FixtureValues;
  currentData: FixtureValues;
  operations: FixtureOperation[];
  expected: {
    hydratedData: FixtureValues;
    persistedData: FixtureValues;
    effects?: RuleEffects;
    embeddedDefinitions?: EmbeddedRichTextFieldDefinition[];
    /** Interaction requirements for the successor browser host; not pure-test proof. */
    browser: {
      requiredRefusal?: string[];
      disabledIds?: string[];
      readonlyIds?: string[];
      remountValues?: FixtureValues;
    };
  };
}

export interface ComponentFixture {
  componentId: string;
  version: number;
  provenance: { activities: string[]; sources: string[]; contractNotes: string[] };
  requiredCaseIds: string[];
  cases: FormFixtureCase[];
  capabilities: { id: string; status: 'supported' | 'pending' | 'unsupported'; reason: string }[];
}

export const FIXTURE_CONTRACT_VERSION = 1;
