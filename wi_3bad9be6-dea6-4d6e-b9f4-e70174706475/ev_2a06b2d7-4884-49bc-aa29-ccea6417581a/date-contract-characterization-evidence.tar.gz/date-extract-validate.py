import json,pathlib,base64,hashlib,sys
p=pathlib.Path(sys.argv[1]);j=json.loads((p/'results.json').read_text());receipt=json.loads((p/'receipt.json').read_text());specs=[]
def walk(s):
 specs.extend(s.get('specs',[]))
 for x in s.get('suites',[]):walk(x)
walk(j)
assert len(specs)==12 and j['stats']['unexpected']==0 and j['stats']['skipped']==0 and j['stats']['flaky']==0
for file,h in receipt['inputHashes'].items():assert hashlib.sha256((p/pathlib.Path(file).name).read_bytes()).hexdigest()==h
allrows=[]
for spec in specs:
 assert len(spec['tests'])==1
 r=spec['tests'][0]['results'][0];assert r['status']=='passed'
 a=next(x for x in r['attachments'] if x['name']=='characterization');obj=json.loads(base64.b64decode(a['body']) if 'body' in a else pathlib.Path(a['path']).read_bytes());allrows.append(obj)
 assert all(x['zone']==x['browserZone'] for x in obj['rows'])
 assert {'author-default','hydrate','untouched-save','untouched-reload','typed-immediate-save','edited-reload','invalid-input'} <= {x['captureStage'] for x in obj['rows']}
 for a in r['attachments']:
  if a.get('contentType')=='image/png':
   target=p/(obj['scenario']['id']+'-'+obj['rows'][0]['zone'].replace('/','_')+'-'+a['name']+'.png');target.write_bytes(base64.b64decode(a['body']) if 'body' in a else pathlib.Path(a['path']).read_bytes())
 print('\n'+spec['title'])
 for row in obj['rows']:
  if row['captureStage'] in ['author-default','hydrate','untouched-save','calendar-immediate-save','typed-immediate-save','edited-reload']:
   raw=json.loads(row['serialized']) if row['serialized'] else {};config=row['container']['items'][0]['renderer']['config'];print(row['captureStage'],[v['value'] for v in row['visible']],row.get('values'),raw.get('formData'), 'default='+str(config.get('defaultValue')))
(p/'observations.json').write_text(json.dumps(allrows,indent=2))
(p/'validation.json').write_text(json.dumps({'execution':'12/12, zero skips/failures/retries','archiveInputHashes':'match','observedBrowserZones':'UTC and America/Edmonton confirmed','certification':'PENDING — probes measure mismatches, not semantic acceptance','stats':j['stats']},indent=2))
print('Receipt and artifact validation PASS; product certification PENDING')
