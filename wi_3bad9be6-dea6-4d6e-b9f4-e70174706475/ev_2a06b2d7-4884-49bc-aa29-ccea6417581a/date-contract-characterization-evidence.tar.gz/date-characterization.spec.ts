import { test, expect } from './fixture';
import { snapshot } from './snapshot';
for (const zone of ['UTC','America/Edmonton']) {
 test.describe(zone,()=>{
  test.use({timezoneId:zone});
  for (const scenario of [
   {id:'legacy-midnight',seed:'2026-01-15T00:00:00.000Z',time:false,day:'03/18/2026'},
   {id:'legacy-offset',seed:'2026-01-15T23:30:00-07:00',time:false,day:'03/18/2026'},
   {id:'legacy-current',seed:'2026-01-15T23:30:00-07:00',current:true,time:false,day:'03/18/2026'},
   {id:'new-day',seed:'2026-01-15',time:false,day:'03/18/2026'},
   {id:'spring-gap',seed:'2026-03-08T07:00:00.000Z',time:true,day:'03/08/2026',clock:'2:30 AM'},
   {id:'fall-overlap',seed:'2026-11-01T06:00:00.000Z',time:true,day:'11/01/2026',clock:'1:30 AM'},
  ]) test(`Characterization ${zone} ${scenario.id}`,async({page},info)=>{
   const rows:any[]=[];
   await page.evaluate(({seed,time,current})=>(window as any).formsProof.seedDate({label:'Contract characterization',inputFormat:time?'MM/DD/YYYY hh:mm A':'MM/DD/YYYY',defaultValue:current?'2026-01-15T00:00:00.000Z':seed,...(time?{timer:{}}:{})},current?seed:undefined),scenario);
   const read=async(stage:string)=>{
    await page.clock.runFor(1); const s=await snapshot(page);
    rows.push({captureStage:stage,zone,seed:scenario.seed,requestedDay:scenario.day,requestedTime:scenario.clock,browserZone:await page.evaluate(()=>Intl.DateTimeFormat().resolvedOptions().timeZone),visible:await page.locator('fs-date-picker input').evaluateAll(es=>es.map((e:any)=>({value:e.value,invalid:e.getAttribute('aria-invalid')}))),...s});
   };
   const shot=async(name:string)=>info.attach(name,{body:await page.screenshot({fullPage:true}),contentType:'image/png'});
   await read('author-default');await shot('author-desktop');await page.setViewportSize({width:390,height:900});await shot('author-narrow');await page.setViewportSize({width:1280,height:1000});
   if(scenario.current) await page.evaluate(seed=>(window as any).formsProof.seedCurrent(seed),scenario.seed); else await page.getByRole('button',{name:'Save authoring',exact:true}).click();
   const input=page.locator('#runtime fs-date-picker input').first();await expect(input).toBeVisible();
   await read('hydrate');
   await page.getByRole('button',{name:'Save runtime',exact:true}).click();await read('untouched-save');
   const m=(await snapshot(page)).mount;await page.getByRole('button',{name:'Reload saved JSON',exact:true}).click();await expect.poll(async()=>(await snapshot(page)).mount).toBe(m+1);await read('untouched-reload');
   if(!scenario.time){
    await page.locator('#runtime').getByRole('button',{name:'Open calendar',exact:true}).click();await expect(page.locator('mat-datepicker-content')).toBeVisible();await page.clock.runFor(250);await shot('calendar');
    const buttons=page.locator('.mat-calendar-body button:not([disabled])');await buttons.nth(19).click();await read('calendar-edit');
    await page.getByRole('button',{name:'Save runtime',exact:true}).click();await read('calendar-immediate-save');
   }
   await input.fill(scenario.day);await input.press('Tab');await read('typed-date');
   if(scenario.time){const clock=page.locator('#runtime fs-date-picker input').nth(1);await clock.fill(scenario.clock!);await clock.press('Tab');await read('typed-time');}
   await page.getByRole('button',{name:'Save runtime',exact:true}).click();await read('typed-immediate-save');
   const mount=(await snapshot(page)).mount;await page.getByRole('button',{name:'Reload saved JSON',exact:true}).click();await expect.poll(async()=>(await snapshot(page)).mount).toBe(mount+1);await read('edited-reload');await shot('runtime-desktop');
   await page.setViewportSize({width:390,height:900});await shot('runtime-narrow');
   await input.fill('not-a-date');await input.press('Tab');await page.getByRole('button',{name:'Extract valid submission',exact:true}).click();await read('invalid-input');await shot('error');
   await info.attach('characterization',{body:Buffer.from(JSON.stringify({scenario,rows},null,2)),contentType:'application/json'});
  });
 });
}
