import moment from 'moment';

import {
    Component,
    ElementRef,
    forwardRef,
    inject,
    Input,
    OnChanges,
    OnInit,
    SimpleChanges,
    viewChild,
    output
} from '@angular/core';
import { provideMomentDateAdapter } from '@angular/material-moment-adapter';
import { MAT_DATE_FORMATS, MatDateFormats } from '@angular/material/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';

import { ButtonConfig } from '../../../fs-button';
import { createFsDateFormats, FSDatePickerConfig } from '../../models/fs-date-picker.model';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { OmniValue } from '../../../shared';

@Component({
    selector: 'fs-date-picker',
    templateUrl: './fs-date-picker.component.html',
    styleUrls: ['./fs-date-picker.component.scss'],
    providers: [
        provideMomentDateAdapter(),
        {
            provide: MAT_DATE_FORMATS,
            useFactory: createFsDateFormats
        },
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => FsDatePickerComponent),
            multi: true
        }
    ],
    standalone: false
})
export class FsDatePickerComponent implements OnChanges, OnInit, ControlValueAccessor {
    private readonly dateFormats = inject<MatDateFormats>(MAT_DATE_FORMATS);

    @Input() name: string;
    @Input() config: FSDatePickerConfig = { e2eSelector: '' };
    @Input() label: OmniValue<string>;
    @Input() isRunningLabel: boolean;
    readonly dateChange = output<Date>();
    readonly dateInput = viewChild.required<ElementRef<HTMLInputElement>>('dateInput');
    readonly timeInput = viewChild.required<ElementRef<HTMLInputElement>>('timeInput');
    timePlaceHolder: string;
    validationType: string;
    minDate: Date | null = null;
    maxDate: Date | null = null;
    minTime: Date | null = null;
    maxTime: Date | null = null;

    selectedDate: moment.Moment | null = null;
    selectedTime: moment.Moment | null = null;
    internalDate: any = null;
    internalTime: any = null;

    cancelBtnConfig: ButtonConfig = {
        e2eSelector: 'fs-picker-btn-cancel',
        onClick: () => ({}),
        label: 'Cancel',
        btnCustomClass: 'fs-date-cancel',
        style: 'basic',
        buttonType: 'button',
        color: 'primary'
    };

    applyBtnConfig: ButtonConfig = {
        e2eSelector: 'fs-picker-btn-confirm',
        label: 'Confirm',
        onClick: () => ({}),
        style: 'raised',
        btnCustomClass: 'fs-date-confirm',
        buttonType: 'button',
        color: 'primary'
    };

    private inputChanged = new Event('inputDate', { bubbles: true, cancelable: true });

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['config']) {
            this.applyConfig();
        }
    }

    ngOnInit(): void {
        this.applyConfig();
    }

    private applyConfig(): void {
        this.validationType = this.config.fsValidationRequired ? 'date' : '';
        this.minDate = this.parseConfiguredDate(this.config.minValue);
        this.maxDate = this.parseConfiguredDate(this.config.maxValue);

        this.applyBtnConfig.label = this.config.pickerBtnConfig?.applyBtnLabel || 'Confirm';
        this.cancelBtnConfig.label = this.config.pickerBtnConfig?.cancelBtnLabel || 'Cancel';

        this.applyDateFormats(this.config.fsDateFormat);

        if (this.config.timer) {
            this.config.timer.icon = this.config.timer.icon ?? 'fs-icon-time';
            this.config.timer.interval = this.config.timer.interval ?? '30min';
        }
        this.config.appearance = this.config.appearance ?? 'outline';
        this.config.icon = this.config.icon ?? 'fs-icon-calendar';

        this.timePlaceHolder = this.dateFormats.display.timeInput;
        if (this.config.setDefaultDate) {
            this.internalDate = this.config.setDefaultDate;
            this.internalTime = this.config.setDefaultDate;
            this.selectedDate = moment(this.config.setDefaultDate);
            this.selectedTime = moment(this.config.setDefaultDate);
        }
        this.updateTimeBounds();
    }

    private applyDateFormats(formats: MatDateFormats | undefined): void {
        const defaults = createFsDateFormats();
        this.dateFormats.parse = {
            ...defaults.parse,
            ...(formats?.parse ?? {})
        };
        this.dateFormats.display = {
            ...defaults.display,
            ...(formats?.display ?? {})
        };
    }

    onDateChange(event: MatDatepickerInputEvent<Date>) {
        this.selectedDate = moment(event.value);
        this.updateTimeBounds();
        this.updateMergedValue();

        setTimeout(() => {
            this.dateInput().nativeElement.dispatchEvent(this.inputChanged);
        });
    }

    onTimeChange(time: any) {
        this.selectedTime = time.value;
        this.updateMergedValue();
        setTimeout(() => {
            this.dateInput().nativeElement.dispatchEvent(this.inputChanged);
        });
    }

    getDateFilter = (d: Date | null): boolean => {
        const date = moment(d);
        if (!date.isValid()) {
            return false;
        }

        if (this.minDate && date.isBefore(moment(this.minDate), 'day')) {
            return false;
        }

        if (this.maxDate && date.isAfter(moment(this.maxDate), 'day')) {
            return false;
        }

        if (!this.config.dateRestriction) {
            return true;
        }

        const today = moment();
        const tomorrow = moment().add(1, 'day');

        switch (this.config.dateRestriction) {
            case 'fromToday':
                return date.isSameOrAfter(today, 'day');
            case 'fromTomorrow':
                return date.isSameOrAfter(tomorrow, 'day');
            case 'onlyPast':
                return date.isSameOrBefore(today, 'day');
            default:
                return true;
        }
    };

    onChange = (value: any) => {};
    onTouched = () => {};

    get inputId(): string {
        return this.name;
    }

    writeValue(value: any): void {
        this.internalDate = value;
        this.internalTime = value;
        if (value) {
            this.selectedDate = moment(value);
            this.selectedTime = moment(value);
        } else {
            this.selectedDate = null;
            this.selectedTime = null;
        }
        this.updateTimeBounds();
    }

    registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    onInputChange(event: any): void {
        this.onChange(event.target.value);
        this.dateInput().nativeElement.dispatchEvent(this.inputChanged);
    }

    onInputBlur(): void {
        this.onTouched();
    }

    getDatePattern(): string {
        return this.dateFormats.display.dateInput;
    }

    onTimeInput(): void {
        if (this.internalTime) {
            const parsedTime = moment(this.internalTime);
            if (parsedTime.isValid() && this.selectedDate?.isValid()) {
                this.selectedTime = parsedTime;
                this.updateMergedValue();
            } else {
                this.onChange(this.internalTime);
            }
            this.dateInput().nativeElement.dispatchEvent(this.inputChanged);
        }
    }

    onDateOrTimeClosed() {
        if (this.config.fsValidationRequired) {
            this.dateInput().nativeElement.dispatchEvent(this.inputChanged);
            this.onTouched();
        }
    }

    updateMergedValue() {
        if (this.selectedDate?.isValid() || this.selectedTime?.isValid()) {
            const merged = this.mergeDateAndTime(this.selectedDate, this.selectedTime);
            if (!merged.isValid()) {
                return;
            }

            const bounded = this.boundDateTime(merged);
            this.selectedDate = bounded.clone();
            this.selectedTime = bounded.clone();
            this.internalDate = bounded;
            this.internalTime = bounded;
            this.onChange(bounded);
            this.onTouched();
            this.dateChange.emit(bounded.toDate());
        }
    }

    private updateTimeBounds(): void {
        this.minTime = null;
        this.maxTime = null;

        if (!this.config.timer || !this.selectedDate?.isValid()) {
            return;
        }

        if (this.minDate && this.selectedDate.isSame(moment(this.minDate), 'day')) {
            this.minTime = this.minDate;
        }

        if (this.maxDate && this.selectedDate.isSame(moment(this.maxDate), 'day')) {
            this.maxTime = this.maxDate;
        }
    }

    private boundDateTime(value: moment.Moment): moment.Moment {
        if (!this.config.timer) {
            return value;
        }

        if (this.minDate && value.isBefore(moment(this.minDate))) {
            return moment(this.minDate);
        }

        if (this.maxDate && value.isAfter(moment(this.maxDate))) {
            return moment(this.maxDate);
        }

        return value;
    }

    mergeDateAndTime(dateMoment: moment.Moment | null, timeMoment: moment.Moment | null): moment.Moment {
        const merged = moment(dateMoment);
        if (timeMoment) {
            merged.hour(timeMoment.hour()).minute(timeMoment.minute()).second(timeMoment.second());
        }
        return merged;
    }

    private parseConfiguredDate(value: Date | string | undefined): Date | null {
        if (!value) {
            return null;
        }

        if (value instanceof Date) {
            return Number.isNaN(value.getTime()) ? null : value;
        }

        const parsedValue = moment(value, moment.ISO_8601, true);
        if (parsedValue.isValid()) {
            return parsedValue.toDate();
        }

        const relaxedValue = moment(value);
        return relaxedValue.isValid() ? relaxedValue.toDate() : null;
    }
}
