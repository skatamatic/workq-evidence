# Date contract characterization — certification PENDING

Investigation complete on merged PR49 / ETC `6621c9b431a714daa82c3f8ef8770c07321292dd`, pinned component library `20.3.16-feature-etc-insight.1791070420`. No product semantic change or migration was made.

## Approved decision

- Time disabled: timezone-invariant calendar day; new intentional edits use `YYYY-MM-DD`. Defaults and current values share this rule. Historical explicit-offset ISO values use their encoded date portion, preserve untouched bytes, and become a day string only on intentional edit. Inclusive min/max and reversed-bound validation compare calendar days. Ambiguous legacy strings are refused.
- Time enabled: explicit-offset instant, canonical UTC `Z` for edits; display/edit in browser IANA timezone. Defaults/current values and inclusive bounds retain instant semantics. Reject DST gaps; require occurrence/offset choice for overlaps. Preserve untouched valid stored instants. No silent migration.

## Measured mismatches

1. `2026-01-15T00:00:00.000Z` displays January 15 under UTC but January 14 in Edmonton, in the real author default editor and hydrated runtime. Calendar selection of January 20 produces `2026-01-20T00:00:00.000Z` under UTC versus `2026-01-21T00:00:00.000Z` in Edmonton, retaining the prior hidden 17:00 local time. Typing March 18 then saving produces `2026-03-18T00:00:00.000Z` versus `2026-03-18T23:00:00.000Z`, rather than `2026-03-18`.
2. Historical `2026-01-15T23:30:00-07:00` displays January 16 in UTC and January 15 in Edmonton. With a distinct configured default, initial author save retains those current bytes; untouched runtime save rewrites them to `2026-01-16T06:30:00.000Z` in both zones. Default-only scenarios omit equal-default current data by the existing save policy and retain raw configured default bytes in this seam; this is distinct from current-value preservation.
3. New day-only `2026-01-15` initially displays the same day in both zones, but hydrated runtime values become ISO (`00:00Z` versus `07:00Z`) and edited values continue to serialize ISO. Hidden time survives date-only calendar/typed edits of non-midnight inputs.
4. Edmonton spring input March 8, 2026 at 02:30 silently becomes 03:30 and saves `2026-03-08T09:30:00.000Z`; no gap rejection. Fall input November 1 at 01:30 silently selects `2026-11-01T07:30:00.000Z`; no occurrence choice. UTC controls save the same requested wall times normally.
5. Invalid `not-a-date` displays a red error, yet the parent control remains `valid: true`, `errors: null`, and the production valid-submission seam returns the invalid string. Both owners must align validation and commit behavior.
6. Bounds mismatch is source-characterized, not browser-certified: `date-field-config.util.ts:265` compares UTC days; `:81` compares reversed bounds as instants. Dedicated negative bound cases belong in the follow-up acceptance suite.

## Exact proof and limits

Existing unmodified focus command selected/executed 5 of 19 cases, excluded 14, skipped zero, with 25 assertions and 58 supporting assertions; completed in 93.9 seconds. Exact `--check-receipt` passed before instrumentation. Baseline: `/Users/kylewesley/.workq-pool/bases/etc-client/cow-clones/workq_wi_3bad9be6-dea6-4d6e-b9f4-e70174706475/test-results/forms-verify/run-NpOXf2/receipt.json`.

Final controlled probes: 12/12 executions, zero failures/skips/retries; 34 seconds. Observed browser timezone matches each requested zone. These are observation runs, not semantic acceptance tests. Receipt, archived source/config/lockfile hashes, results, observations and validation: `/Users/kylewesley/.workq-pool/bases/etc-client/cow-clones/workq_wi_3bad9be6-dea6-4d6e-b9f4-e70174706475/test-results/date-characterization-FrvSSv`. Each case records author default, hydration, untouched save/reload, calendar edit (date-only), typed edit, immediate save, edited reload and invalid input separately. Runtime control/extracted values and serialized formData are recorded independently of visible inputs. Browser host uses production editor/picker/builder save/reader/runtime; the sole temporary host addition seeds fixture inputs. JSON in-memory transport only; no HTTP/database, customer-format matrix, legacy ambiguity corpus, full Jenkins matrix or completed fixes certified.

Visual review: inspected exact UTC/Edmonton desktop default, Edmonton narrow author/runtime, calendar, invalid/error, spring and fall runtime PNGs. Desktop and 390px inspected controls are readable; narrow min/max placeholders are cramped but contained. Default/editor and calendar show the previous-day error. Calendar capture has a translucent overlay and proves open/selected date, not animation quality. Error picture visibly contradicts successful submission. DST pictures show normalized gap and absence of overlap disambiguation. No UX redesign or human visual gate was requested.

## Owner handoff

ETC: mode-aware persistence/parsing, current/default byte preservation, day bounds, picker validation propagation and refusal at save/submission; source-path risks and focused acceptance tests in `date-etc-implementation-brief.md`.

Component library: separate calendar-day/instant model and event contract, eliminate hidden time in day mode, strict typed commit/validation, browser IANA gap rejection and explicit overlap choice; pinned-source citations and acceptance tests in `date-library-implementation-brief.md`. Publish a coordinated library version, then consume/test it in ETC. No owner-repo edits were bundled here. Certification remains pending until those fixes pass the UTC/Edmonton contract suite and required CI.
