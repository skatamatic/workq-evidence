import 'zone.js';
import { generateAllComponentsRequest } from '../../../src/testing/form-fixtures/catalog';
import english from '../../../src/assets/i18n/en.json';
import { DateConfigEditorComponent } from '@main/components/forms/modals/editors/date-config-editor.component';
import { createFormsConsoleDiagnostics } from '../../../src/testing/forms-console-diagnostics';
const diagnostics = createFormsConsoleDiagnostics(console.error.bind(console));
console.error = diagnostics.guardedError;
import { Component, InjectionToken, Injectable, importProvidersFrom, inject, signal, viewChild } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideAnimations } from '@angular/platform-browser/animations';
import { FormsModule, NgForm } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { FS_VIEW_TYPE, FsModalService, FSRichTextFieldConfig } from '@flatirons/component-library';
import { FormDefinitionService } from '@backend/api/form-definitions.service';
import { IFormDefinitionDto } from '@backend/model/interface/form-definition-dto.interface';
import { FormContainerComponent } from '@main/components/forms/components/form-container.component';
import {
  Container,
  GenericFieldItem,
  RichTextItem,
  RichTextViewRenderer,
} from '@main/components/forms/models/builder-item.model';
import { FormRule, FormRuleRegistry } from '@main/components/forms/models/form-rule.model';
import { FormBuilderScope } from '@main/components/forms/models/form-builder-scope.model';
import { renameRuleReferences } from '@main/components/forms/utils/form-rule-lifecycle.util';
import { DropdownConfigEditorComponent } from '@main/components/forms/modals/editors/dropdown-config-editor.component';
import { RichTextConfigEditorComponent } from '@main/components/forms/modals/editors/rich-text-config-editor.component';
import { FormBuilderSaveService } from '@main/components/forms/service/form-builder-save.service';
import { readPersistedFormDefinition } from '@main/components/forms/utils/form-definition-data.util';
import { FormRendererComponent } from '@shared/components/form-renderer/form-renderer.component';
import { DateFieldConfig, DropdownFieldConfig } from '@shared/components/dynamic-field/field-renderer.types';
import { FixtureValues } from '../../../src/testing/form-fixtures/fixture-contract';
import { fixtures } from '../../../src/testing/form-fixtures/registry.generated';
import { selectSourceBackedCase } from '../../../src/testing/form-fixtures/source-backed-contract';

/** The only substituted seam: owned memory transport, never a product service implementation. */
@Injectable()
class JsonFixtureTransport {
  serialized = '';
  write(payload: IFormDefinitionDto): void {
    this.serialized = JSON.stringify(payload);
  }
  read(): IFormDefinitionDto {
    return JSON.parse(this.serialized);
  }
}
const FIXTURE_TRANSPORT = new InjectionToken<JsonFixtureTransport>('forms browser fixture transport');

@Component({
  selector: 'app-forms-browser-host',
  standalone: true,
  imports: [
    FormsModule,
    FormContainerComponent,
    FormRendererComponent,
    DropdownConfigEditorComponent,
    RichTextConfigEditorComponent,
    DateConfigEditorComponent,
  ],
  template: `
    <header class="proof-header">
      <div>
        <span class="eyebrow">eTaskCard / Component lab</span>
        <h1>Isolated forms browser proof</h1>
        <p>Author with production controls. Save JSON. Remount and verify.</p>
      </div>
      <span class="seam-badge">Local transport · No backend</span>
    </header>
    <nav aria-label="Component pilots">
      @for (fixture of registeredFixtures; track fixture.componentId) {
        <button
          [attr.aria-pressed]="pilot === fixture.componentId"
          (click)="load(fixture.componentId)"
        >
          {{ pilotLabel(fixture.componentId) }} pilot
        </button>
      }
      <button (click)="loadShowcase()">All components</button>
    </nav>
    <label
      >Registered case
      <select
        id="fixture-case"
        (change)="loadCase($any($event.target).value)"
      >
        <option value="">Choose case</option>
        @for (id of caseIds; track id) {
          <option [value]="id">{{ id }}</option>
        }
      </select>
    </label>
    @if (stage() === 'author') {
      <section id="author">
        <h2>Production authoring</h2>
        @if (pilot === 'date') {
          <app-date-config-editor
            [model]="dateConfig"
            [label]="dateConfig.label || ''"
            localizationBase="formBuilder.modal.objectConfig"
            (modelChange)="configureDate($event)"
            (labelChange)="configureDateLabel($event)"
          />
        } @else if (pilot !== 'embedded') {
          <app-dropdown-config-editor
            [model]="dropdownConfig"
            [label]="dropdownConfig.label"
            [optionsText]="optionsText"
            localizationBase="formBuilder.modal.objectConfig"
            (modelChange)="configureDropdown($event)"
            (labelChange)="configureDropdownLabel($event)"
            (optionsTextChange)="optionsText = $event"
          />
        } @else {
          <app-rich-text-config-editor
            [model]="richConfig"
            localizationBase="formBuilder.modal.objectConfig"
            [viewRenderer]="richItem.viewRenderer"
            (modelChange)="configureRich($event)"
            (viewRendererChange)="configureRichRenderer($event)"
          />
        }
        <form #authorForm="ngForm">
          <app-form-container
            [container]="container()"
            [rootContainer]="container()"
            [isFormBuilder]="true"
            [context]="data"
            [builderScope]="authorScope()"
            (ruleTargetRulesChanged)="rulesChanged($event)"
            (builderFieldValueChange)="authorChange($event)"
          />
        </form>
        <button (click)="saveAuthor()">Save authoring</button>
      </section>
    } @else {
      <section id="runtime">
        <h2>Fresh production runtime mount {{ mount() }}</h2>
        @if (mounted()) {
          <fs-form-renderer
            #runtime
            [container]="container()"
            [value]="runtimeData"
            [definitionData]="definitionData"
            [ruleRegistry]="registry"
            [mode]="readonly() ? 'view' : 'edit'"
            [disabled]="readonly() || externalDisabled()"
          />
        }
        <button (click)="saveRuntime()">Save runtime</button>
        <button (click)="reload()">Reload saved JSON</button>
        <button (click)="submit()">Extract valid submission</button>
        <button (click)="readonly.set(!readonly())">Toggle readonly</button>
        <button (click)="externalDisabled.set(!externalDisabled())">Toggle external disabled</button>
        <output id="submission">{{ submission }}</output>
      </section>
      @if (pilot === 'embedded') {
        <section id="isolated-scope">
          <h2>Independent scope, same field IDs</h2>
          <fs-form-renderer
            #other
            [container]="container()"
            [value]="scopeData"
            [definitionData]="definitionData"
            [ruleRegistry]="registry"
          />
        </section>
      }
    }
    @if (pilot === 'source-feedback') {
      <button (click)="load('source-feedback', 'explicit-clear')">Source empty input</button>
      <button (click)="refuseUnsupportedSource()">Attempt unsupported legacy mapping</button>
      <output id="source-refusal">{{ sourceRefusal }}</output>
    }
    <output
      role="status"
      aria-live="polite"
      id="save-status"
      >{{ status }}</output
    >
  `,
  styleUrl: './host.css',
})
class FormsBrowserHost {
  readonly registeredFixtures = fixtures;
  pilotLabel(id: string): string {
    return id === 'source-feedback' ? 'Source' : id.charAt(0).toUpperCase() + id.slice(1);
  }
  readonly caseIds = fixtures.flatMap((fixture) =>
    fixture.cases.map((entry) => `${fixture.componentId}/${entry.caseId}`)
  );
  private readonly save = inject(FormBuilderSaveService);
  private readonly transport = inject(FIXTURE_TRANSPORT);
  readonly renderer = viewChild<FormRendererComponent>('runtime');
  readonly other = viewChild<FormRendererComponent>('other');
  readonly authorForm = viewChild<NgForm>('authorForm');
  readonly container = signal<Container>({ id: 'empty', type: 'container', layout: 'column', items: [] });
  readonly stage = signal<'author' | 'runtime'>('author');
  readonly mounted = signal(true);
  readonly mount = signal(0);
  readonly readonly = signal(false);
  readonly externalDisabled = signal(false);
  pilot = 'dropdown';
  registry: FormRuleRegistry = { rules: [] };
  readonly authorScope = signal<FormBuilderScope>({ rootId: 'empty', formData: {}, ruleRegistry: { rules: [] } });
  data: FixtureValues = {};
  runtimeData: FixtureValues = {};
  definitionData: FixtureValues = {};
  scopeData: FixtureValues = {};
  optionsText = '';
  status = '';
  submission = '';
  sourceRefusal = '';

  constructor() {
    const translate = inject(TranslateService);
    translate.setTranslation('en', english);
    translate.use('en');
    this.load('dropdown');
    // Read-only observability for semantic DOM/model assertions and artifact capture.
    Object.assign(window, { formsProof: { seedCurrent: (value: string) => { this.data = { [this.dropdownItem.id]: value }; this.saveAuthor(); }, snapshot: () => this.snapshot(), seedDate: (config: DateFieldConfig, current?: string) => { this.load('date'); this.configureDate(config); this.data = current === undefined ? {} : { [this.dropdownItem.id]: current }; this.authorScope.set({ rootId: this.container().id, formData: this.data, ruleRegistry: this.registry }); } } });
  }
  get dropdownItem(): GenericFieldItem {
    return this.container().items[0] as GenericFieldItem;
  }
  get dropdownConfig(): DropdownFieldConfig {
    return this.dropdownItem.renderer!.config as DropdownFieldConfig;
  }
  get richItem(): RichTextItem {
    return this.container().items[1] as RichTextItem;
  }
  get richConfig(): FSRichTextFieldConfig {
    return { name: this.richItem.id, ...this.richItem.config };
  }

  load(pilot: string, sourceCaseId = 'supported-selection'): void {
    const fixture = fixtures.find((f) => f.componentId === pilot)!;
    const entry =
      pilot === 'source-feedback'
        ? selectSourceBackedCase(fixture, 'static-action', sourceCaseId)
        : structuredClone(fixture.cases.find((c) => c.caseId === fixture.browser.authoringCaseId)!);
    this.pilot = pilot;
    this.container.set(entry.definition);
    this.registry = entry.ruleRegistry;
    this.data = pilot === 'dropdown' ? {} : entry.currentData;
    if (pilot === 'embedded') {
      const rule = this.registry.rules[0];
      this.registry = {
        rules: ['hide', 'disable', 'enable'].map((action) => ({
          ...rule,
          ruleId: `${rule.ruleId}-${action}`,
          action: action as 'hide' | 'disable' | 'enable',
          condition: { operator: 'equals', value: action },
        })),
      };
      this.data[rule.sourceItemId] = 'Retained notes';
    }
    this.authorScope.set({ rootId: this.container().id, formData: this.data, ruleRegistry: this.registry });
    this.optionsText =
      pilot === 'date' ? '' : Array.isArray(this.dropdownConfig.data) ? this.dropdownConfig.data.join('\n') : '';
    if (pilot === 'embedded') {
      this.configureDropdown({
        ...this.dropdownConfig,
        data: [
          ...(Array.isArray(this.dropdownConfig.data)
            ? this.dropdownConfig.data.filter((option): option is string => typeof option === 'string')
            : []),
          'Closed',
        ],
      });
    }
    this.status = '';
    this.submission = '';
    this.readonly.set(false);
    this.externalDisabled.set(false);
    this.stage.set('author');
  }
  loadShowcase(): void {
    const request = generateAllComponentsRequest(fixtures);
    this.pilot = 'showcase';
    if (!request.container) throw new Error('Missing showcase structure');
    this.container.set(request.container);
    this.registry = request.ruleRegistry ?? { rules: [] };
    this.readonly.set(false);
    this.externalDisabled.set(false);
    this.transport.write(this.save.buildPayload(request));
    this.status = 'Saved JSON';
    this.reload();
  }
  loadCase(id: string): void {
    const [componentId, caseId] = id.split('/');
    const fixture = fixtures.find((candidate) => candidate.componentId === componentId);
    if (!fixture) {
      throw new Error(`Unknown registered component: ${componentId}`);
    }
    let entry = fixture.cases.find((candidate) => candidate.caseId === caseId);
    if (fixture.sourceManifest) {
      const mapping = fixture.sourceManifest.mappings.find(
        (candidate) => candidate.status === 'supported' && candidate.caseIds.includes(caseId)
      );
      if (!mapping) {
        throw new Error(`Unsupported source case: ${id}`);
      }
      entry = selectSourceBackedCase(fixture, mapping.mappingId, caseId);
    }
    if (!entry) {
      throw new Error(`Unknown registered case: ${id}`);
    }
    this.pilot = componentId;
    this.container.set(structuredClone(entry.definition));
    this.registry = structuredClone(entry.ruleRegistry);
    this.readonly.set(entry.operations.includes('readonly'));
    this.externalDisabled.set(false);
    this.submission = '';
    this.persist(structuredClone(entry.currentData));
    this.reload();
  }
  refuseUnsupportedSource(): void {
    const fixture = fixtures.find((entry) => entry.componentId === 'source-feedback');
    if (!fixture) {
      throw new Error('Missing source fixture');
    }
    try {
      selectSourceBackedCase(fixture, 'legacy-empty-sentinel', 'supported-selection');
      throw new Error('Unsupported mapping unexpectedly accepted');
    } catch (error) {
      if (!(error instanceof Error) || !error.message.startsWith('Unsupported source mapping:')) throw error;
      this.sourceRefusal = error.message;
    }
  }
  rulesChanged(change: {
    scopeRootId: string;
    targetItemId: string;
    previousTargetItemId?: string;
    rules: FormRule[];
  }): void {
    if (change.scopeRootId !== this.container().id) throw new Error('Wrong authoring scope');
    this.registry = {
      rules: [
        ...renameRuleReferences(
          this.registry,
          change.previousTargetItemId ?? change.targetItemId,
          change.targetItemId
        ).rules.filter((rule) => rule.targetItemId !== change.targetItemId),
        ...structuredClone(change.rules),
      ],
    };
    this.authorScope.set({ rootId: this.container().id, formData: this.data, ruleRegistry: this.registry });
  }
  get dateConfig(): DateFieldConfig {
    return this.dropdownItem.renderer!.config as DateFieldConfig;
  }
  configureDateLabel(label: string): void {
    this.configureDate({ ...this.dateConfig, label });
  }
  configureDate(config: DateFieldConfig): void {
    this.container.set({ ...this.container(), items: [{ ...this.dropdownItem, renderer: { type: 'date', config } }] });
  }
  configureDropdownLabel(label: string): void {
    this.configureDropdown({ ...this.dropdownConfig, label });
  }
  configureDropdown(config: DropdownFieldConfig): void {
    this.container.set({
      ...this.container(),
      items: [{ ...this.dropdownItem, renderer: { type: 'dropdown', config } }, ...this.container().items.slice(1)],
    });
  }
  configureRich(config: FSRichTextFieldConfig): void {
    this.container.set({ ...this.container(), items: [this.dropdownItem, { ...this.richItem, config }] });
  }
  configureRichRenderer(viewRenderer: RichTextViewRenderer | undefined): void {
    this.container.set({ ...this.container(), items: [this.dropdownItem, { ...this.richItem, viewRenderer }] });
  }
  authorChange(change: { fieldId: string; value: FixtureValues[string] }): void {
    if (change.value === undefined) delete this.data[change.fieldId];
    else this.data[change.fieldId] = change.value;
  }
  private persist(data: FixtureValues): void {
    const payload = this.save.buildPayload({
      container: this.container(),
      formData: data,
      ruleRegistry: this.registry,
      subtemplates: [],
      formType: 'Standalone',
      libraryId: 0,
      dialog: {
        name: `Browser ${this.pilot}`,
        description: 'In-memory serialization/rendering proof',
        revisionComment: 'browser-pilot',
      },
    });
    this.transport.write(payload);
    this.status = 'Saved JSON';
  }
  saveAuthor(): void {
    this.persist(this.data);
    this.reload();
  }
  saveRuntime(): void {
    this.persist(this.renderer()!.getCurrentFormData());
  }
  reload(): void {
    const payload = this.transport.read();
    const envelope = readPersistedFormDefinition(payload.formDefinition);
    if (!envelope) throw new Error('Production reader rejected saved envelope');
    this.container.set(envelope.structure);
    this.registry = envelope.ruleRegistry;
    this.definitionData = structuredClone(payload.formData ?? {});
    this.runtimeData = structuredClone(payload.formData ?? {});
    this.scopeData = structuredClone(payload.formData ?? {});
    this.stage.set('runtime');
    this.mounted.set(false);
    // A render boundary destroys the old renderer before creating an independent instance.
    requestAnimationFrame(() => {
      this.mount.update((n) => n + 1);
      this.mounted.set(true);
    });
  }
  submit(): void {
    const renderer = this.renderer()!;
    if (renderer.fsForm()?.form?.disabled) {
      this.submission = 'Disabled form refusal';
      return;
    }
    this.submission = renderer.fsForm()!.validateOnBtnClick()
      ? JSON.stringify(renderer.getCurrentFormData())
      : 'Required refusal';
  }
  snapshot() {
    const renderer = this.renderer();
    const form = renderer?.fsForm()?.form;
    return {
      diagnostics: diagnostics.failures(),
      definitionErrors: this.save.validateDefinition(
        this.container(),
        this.stage() === 'author' ? this.data : this.definitionData,
        this.registry,
        []
      ),
      pilot: this.pilot,
      stage: this.stage(),
      mount: this.mount(),
      container: this.container(),
      registry: this.registry,
      authorData: this.data,
      values: renderer?.getCurrentFormData(),
      retainedValues: renderer?.formContext(),
      otherValues: this.other()?.getCurrentFormData(),
      controls:
        form instanceof NgForm
          ? Object.fromEntries(
              Object.entries(form.controls).map(([id, c]) => [
                id,
                { value: c.value, disabled: c.disabled, valid: c.valid, errors: c.errors },
              ])
            )
          : {},
      effects: renderer?.ruleEffects(),
      serialized: this.transport.serialized,
      submission: this.submission,
    };
  }
}
bootstrapApplication(FormsBrowserHost, {
  providers: [
    provideAnimations(),
    FsModalService,
    importProvidersFrom(TranslateModule.forRoot(), MatDialogModule, MatBottomSheetModule),
    { provide: FS_VIEW_TYPE, useValue: 'WebView' },
    JsonFixtureTransport,
    { provide: FIXTURE_TRANSPORT, useExisting: JsonFixtureTransport },
    {
      provide: FormDefinitionService,
      useValue: {
        createForm: () => {
          throw new Error('Unexpected createForm backend call');
        },
        updateForm: () => {
          throw new Error('Unexpected updateForm backend call');
        },
        getFormsByAncestor: () => {
          throw new Error('Unexpected lineage backend call');
        },
      },
    },
  ],
}).catch((error) => {
  console.error(error);
});
